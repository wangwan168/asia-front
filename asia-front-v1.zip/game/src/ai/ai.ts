// 规则 AI：每国按 aiPersonality（侵略/扩张/工业/谨慎）决策，全部动作只经 applyAction 落地。
// 备战期：建厂/造兵/科研/国策；战争期：按局部战力比决定进攻（攻击模式按情形选）、
// 劣势收缩、游击势力渗透敌后。外交：同阵营结盟、 opportunist 宣战（1938 年前以事件驱动为主）、劣势求和。

import { FACTIONS } from "../data/factions";
import { FOCUS_MAP } from "../data/focuses";
import { PROVINCE_MAP } from "../data/provinces";
import { TEMPLATES } from "../data/units";
import { estimateAttack } from "../core/combat";
import { ATTACK_MODES, type AttackModeId } from "../data/attackModes";
import { neighborsOf, isSeaEdge } from "../core/mapGraph";
import { reachableWithin } from "../core/movement";
import { hexDistance } from "../core/hex";
import {
  factionPower, isAllied, isAtWar, ownedProvinces, relationOf,
} from "../core/relations";
import { createRng } from "../core/rng";
import type { GameAction } from "../core/applyAction";
import type { GameState } from "../state/types";

const MAX_AI_ACTIONS = 60;

function neighborFactions(state: GameState, factionId: string): Set<string> {
  const result = new Set<string>();
  for (const pid of ownedProvinces(state, factionId)) {
    for (const nb of neighborsOf(pid)) {
      const owner = state.provinces[nb]?.ownerId;
      if (owner && owner !== "neutral" && owner !== factionId) result.add(owner);
    }
  }
  return result;
}

function atWarWithAnyone(state: GameState, factionId: string): string[] {
  return Object.keys(state.factions).filter(
    (o) => o !== factionId && isAtWar(state, factionId, o),
  );
}

export function planAiActions(state: GameState, factionId: string): GameAction[] {
  const f = state.factions[factionId];
  const def = FACTIONS[factionId as keyof typeof FACTIONS];
  if (!f || !def || !f.active || !f.alive) return [];
  const actions: GameAction[] = [];
  const rng = createRng(state.seed).derive(`ai:${factionId}:${state.turn}`);
  const persona = def.aiPersonality;
  const capital = def.capitalProvinceId;
  const owned = ownedProvinces(state, factionId);
  if (owned.length === 0 && state.divisions.every((d) => d.factionId !== factionId)) return [];
  const wars = atWarWithAnyone(state, factionId);
  const atWar = wars.length > 0;

  // 科研：未设定时按性格选分支
  if (!f.researchBranch) {
    const branches: Array<"industry" | "infantry" | "artillery" | "armor" | "air" | "navy"> =
      persona.industry >= 0.6
        ? ["industry", "infantry", "artillery", "armor", "air"]
        : ["infantry", "artillery", "armor", "industry", "navy"];
    actions.push({
      type: "SET_RESEARCH", factionId,
      branch: branches[state.turn % branches.length]!,
    });
  }

  // 国策：无进行中时启动第一个未完成的
  if (!f.focusId) {
    const next = Object.values(FOCUS_MAP).find(
      (fc) => fc.factionId === factionId && !f.completedFocuses.includes(fc.id),
    );
    if (next) actions.push({ type: "START_FOCUS", factionId, focusId: next.id });
  }

  // 建厂：建设点够两座时建一座军工（工业倾向低的建民用）
  if (f.constructionPoints >= 120 && owned.length > 0) {
    const best = [...owned].sort(
      (a, b) => (PROVINCE_MAP[b]!.industry) - (PROVINCE_MAP[a]!.industry),
    )[0]!;
    actions.push({
      type: "BUILD_FACTORY", factionId, provinceId: best,
      factory: persona.industry >= 0.4 ? "mil" : "civ",
    });
  }

  // 造兵：前线省优先（交战时），否则首都
  const front = owned.find((pid) => neighborsOf(pid).some(
    (nb) => {
      const o = state.provinces[nb]?.ownerId;
      return o && o !== "neutral" && isAtWar(state, factionId, o);
    },
  ));
  const buildAt = (atWar && front) ? front : (owned.includes(capital) ? capital : owned[0]);
  if (buildAt) {
    const queued = state.production.filter((p) => p.factionId === factionId).length;
    if (queued < 4) {
      const specialty = Object.values(TEMPLATES).find((t) => t.factionId === factionId);
      let templateId = "infantry";
      if (specialty && rng.next() < 0.5) templateId = specialty.id;
      else if (f.stockpile.equipment > 420 && persona.industry > 0.5 && rng.next() < 0.4) templateId = "armor";
      else if (persona.caution > 0.7 && !atWar) templateId = "garrison";
      else if (TEMPLATES[templateId] && def.id === "ccp") templateId = "eighthRoute";
      const tpl = TEMPLATES[templateId]!;
      if (f.stockpile.equipment >= tpl.equipmentCost * 1.2 && f.stockpile.manpower >= tpl.fullStrength * 1.5) {
        actions.push({ type: "BUILD_DIVISION", factionId, provinceId: buildAt, templateId });
      }
    }
    // 空军：装备富余且无战斗机时补一联队
    if (f.stockpile.equipment > 650 && !state.supports.some((s) => s.factionId === factionId && s.kind === "fighter")) {
      actions.push({ type: "BUILD_SUPPORT", factionId, provinceId: buildAt, kind: "fighter" });
    }
  }

  // 外交
  const monthsSinceStart = (state.year - 1936) * 12 + (state.month - 1);
  if (!atWar && monthsSinceStart >= 24 && persona.aggression > 0.55 && rng.next() < persona.aggression) {
    // 机会主义宣战：挑相邻弱者（非盟友、无互不侵犯、关系冷淡）
    const myPower = factionPower(state, factionId);
    for (const other of neighborFactions(state, factionId)) {
      const of = state.factions[other];
      if (!of || !of.active || !of.alive || of.vassalOf === factionId) continue;
      if (isAllied(state, factionId, other)) continue;
      if (state.nonAggression.includes([factionId, other].sort().join("__"))) continue;
      if (relationOf(state, factionId, other) >= 60) continue;
      if (factionPower(state, other) < myPower * (0.35 + persona.aggression * 0.3)) {
        actions.push({ type: "DIPLOMACY", factionId, targetId: other, actionId: "declareWar" });
        break;
      }
    }
  }
  // 盟友参战：与盟友关系极深（>=90）且自身不怯战时，主动对其敌人宣战（如满洲国随日本对华作战）。
  // 门槛定 90 是为了防连锁：结盟动作本身会 +15 关系，中苏初始 70 结盟后 85 仍不达标，
  // 苏联不会被拖入中国内战；日满初始 90、日蒙（蒙疆）结盟后 90 才够格参战。
  if (!atWar || persona.aggression >= 0.35) {
    for (const ally of Object.keys(state.factions)) {
      if (ally === factionId || !isAllied(state, factionId, ally)) continue;
      if (relationOf(state, factionId, ally) < 90) continue;
      const allyWars = atWarWithAnyone(state, ally);
      for (const enemy of allyWars) {
        if (enemy === factionId || isAtWar(state, factionId, enemy)) continue;
        if (relationOf(state, factionId, enemy) >= 60) continue;
        if (persona.aggression >= 0.35 && rng.next() < 0.6) {
          actions.push({ type: "DIPLOMACY", factionId, targetId: enemy, actionId: "declareWar" });
        }
      }
    }
  }
  if (atWar) {
    // 劣势求和（谨慎者）
    const myPower = factionPower(state, factionId);
    for (const enemy of wars) {
      if (persona.caution > 0.5 && factionPower(state, enemy) > myPower * 1.6 && rng.next() < 0.5) {
        actions.push({ type: "DIPLOMACY", factionId, targetId: enemy, actionId: "peace" });
      }
    }
    // 同阵营结盟
    for (const other of Object.keys(state.factions)) {
      const of = state.factions[other];
      if (!of || other === factionId || !of.active || !of.alive) continue;
      if (of.bloc === f.bloc && f.bloc !== "neutral" && !isAllied(state, factionId, other)
        && relationOf(state, factionId, other) >= 65) {
        actions.push({ type: "DIPLOMACY", factionId, targetId: other, actionId: "alliance" });
        break;
      }
    }
  }

  // 军事：以省份为单位组织进攻；其余部队向前线机动
  const myDivisions = state.divisions.filter((d) => d.factionId === factionId && d.movedTurn < state.turn);
  const byProvince = new Map<string, number>();
  for (const d of myDivisions) byProvince.set(d.provinceId, (byProvince.get(d.provinceId) ?? 0) + 1);
  const attackedFrom = new Set<string>();
  for (const pid of byProvince.keys()) {
    const enemyNeighbors = neighborsOf(pid).filter((nb) => {
      const o = state.provinces[nb]?.ownerId;
      return (o && o !== "neutral" && isAtWar(state, factionId, o))
        || state.divisions.some((d) => d.provinceId === nb && isAtWar(state, factionId, d.factionId));
    });
    if (enemyNeighbors.length === 0) continue;
    let bestTarget: string | null = null;
    let bestRatio = 0;
    for (const nb of enemyNeighbors) {
      const hasGuerrilla = myDivisions.some(
        (d) => d.provinceId === pid && TEMPLATES[d.templateId]?.guerrilla,
      );
      const mode = hasGuerrilla ? "guerrilla_raid" : "frontal_assault";
      const est = estimateAttack(state, factionId, pid, nb, mode);
      if (est && est.ratio > bestRatio) {
        bestRatio = est.ratio;
        bestTarget = nb;
      }
    }
    if (bestTarget && bestRatio > 1.15 + (1 - persona.aggression) * 0.3) {
      const hasGuerrilla = myDivisions.some(
        (d) => d.provinceId === pid && TEMPLATES[d.templateId]?.guerrilla,
      );
      const hasSupport = state.supports.some(
        (s) => s.factionId === factionId && (s.provinceId === pid || s.provinceId === bestTarget),
      );
      const readyHere = myDivisions.filter((d) => d.provinceId === pid);
      const hasLightUnit = readyHere.some(
        (d) => ATTACK_MODES.infiltration.requiresTemplates?.includes(d.templateId),
      );
      let mode: AttackModeId = hasGuerrilla ? "guerrilla_raid" : "frontal_assault";
      if (isSeaEdge(pid, bestTarget)) mode = "amphibious_landing";
      else if (readyHere.every((d) => d.staticMonths >= 2) && readyHere.length > 0 && rng.next() < 0.6) {
        mode = "prepared_offensive"; // 静止筹备已攒层，优先打筹备攻势
      } else if (hasSupport && rng.next() < 0.5) mode = "air_support";
      else if (!hasGuerrilla && hasLightUnit && rng.next() < 0.3) mode = "infiltration";
      actions.push({
        type: "ATTACK", factionId, fromProvinceId: pid, targetProvinceId: bestTarget, mode,
      });
      attackedFrom.add(pid);
    }
  }
  // 机动：不在进攻省份的部队向最近的敌邻省份靠拢
  const enemyProvinces = Object.values(state.provinces)
    .filter((p) => p.ownerId !== "neutral" && isAtWar(state, factionId, p.ownerId))
    .map((p) => p.id);
  if (enemyProvinces.length > 0) {
    for (const div of myDivisions) {
      if (attackedFrom.has(div.provinceId)) continue;
      if (actions.length >= MAX_AI_ACTIONS) break;
      const reach = reachableWithin(state, div);
      if (reach.size === 0) continue;
      let bestProv: string | null = null;
      let bestDist = Number.POSITIVE_INFINITY;
      for (const cand of reach.keys()) {
        const candDef = PROVINCE_MAP[cand]!;
        for (const ep of enemyProvinces) {
          const dist = hexDistance(candDef, PROVINCE_MAP[ep]!);
          if (dist < bestDist) {
            bestDist = dist;
            bestProv = cand;
          }
        }
      }
      if (bestProv && bestProv !== div.provinceId) {
        actions.push({
          type: "MOVE_DIVISION", factionId, divisionId: div.id, toProvinceId: bestProv,
        });
      }
    }
  }

  return actions.slice(0, MAX_AI_ACTIONS);
}
