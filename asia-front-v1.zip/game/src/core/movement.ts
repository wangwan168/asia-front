// 移动可达性：BFS 按师速度（格/回合）展开。通行规则：
// - 不得穿过交战敌方省份（游击单位例外：可渗透进入/穿过敌控省份）；
// - 跨海航线边可走（运输船抽象），但目标省有敌舰队支援单位时封锁；
// - 终点若是敌控省份（非游击单位）必须走 ATTACK，不能用 MOVE 占领。

import { neighborsOf, isSeaEdge } from "./mapGraph";
import { isAtWar } from "./relations";
import { TEMPLATES } from "../data/units";
import type { DivisionState, GameState } from "../state/types";

export function reachableWithin(state: GameState, div: DivisionState): Map<string, number> {
  const tpl = TEMPLATES[div.templateId];
  const result = new Map<string, number>();
  if (!tpl) return result;
  result.set(div.provinceId, 0);
  let frontier = [div.provinceId];
  for (let step = 1; step <= tpl.speed; step += 1) {
    const next: string[] = [];
    for (const cur of frontier) {
      for (const nb of neighborsOf(cur)) {
        if (result.has(nb)) continue;
        const owner = state.provinces[nb]?.ownerId ?? "neutral";
        const enemyOwned = owner !== "neutral" && isAtWar(state, div.factionId, owner);
        if (enemyOwned && !tpl.guerrilla) continue;
        if (isSeaEdge(cur, nb)) {
          const blockaded = state.supports.some(
            (s) => s.provinceId === nb && s.kind === "fleet" && isAtWar(state, div.factionId, s.factionId),
          );
          if (blockaded) continue;
        }
        result.set(nb, step);
        next.push(nb);
      }
    }
    frontier = next;
  }
  result.delete(div.provinceId);
  return result;
}
