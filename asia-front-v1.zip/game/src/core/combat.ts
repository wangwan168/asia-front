// 战斗结算（数据驱动攻击模式表 data/attackModes.ts；模式口径参考钢4后按月回合制压缩，见该文件注释）。
// 战力 = Σ 师基础攻/防 x 编制比 x 地形 x 克制 x 科技（乘项积封顶 0.3-3.0）x 模式 x 支援 x 随机(0.85-1.15)。
// 战损折算实际人数；守军全灭或被击退则攻方占领。模式特殊效果一律读 effects 标记枚举做通用
// 处理（noOccupy/raidIndustry/fleetEscortBonus/ignoresSeaRequirement），本文件不按 mode id 特判。
// 随机只走 core/rng 派生子流（同种子可复现）。

import { ATTACK_MODES, type AttackModeId, type AttackModeDef } from "../data/attackModes";
import { PROVINCE_MAP } from "../data/provinces";
import { TEMPLATES, type DivisionTemplate } from "../data/units";
import { clamp } from "./guards";
import { neighborsOf, isSeaEdge } from "./mapGraph";
import { isAtWar, pushLog } from "./relations";
import { suppliedProvinces } from "./supply";
import { createRng } from "./rng";
import type { DivisionState, GameState } from "../state/types";

const DESTROY_THRESHOLD = 300;
const MULT_MIN = 0.3;
const MULT_MAX = 3.0;

function techMult(state: GameState, div: DivisionState, role: "atk" | "def"): number {
  const f = state.factions[div.factionId];
  const tpl = TEMPLATES[div.templateId]!;
  if (!f) return 1;
  let m = 1;
  if (tpl.cls === "infantry" || tpl.cls === "mountain" || tpl.cls === "garrison") {
    m *= 1 + 0.08 * (f.tech.infantry ?? 0);
  }
  if (tpl.cls === "armor" || tpl.cls === "motorized") {
    m *= 1 + 0.1 * (f.tech.armor ?? 0);
  }
  if (role === "atk") m *= 1 + 0.07 * (f.tech.artillery ?? 0);
  return m;
}

function supportMult(
  state: GameState, factionId: string, ownProvince: string, foeProvince: string,
  role: "atk" | "def", targetTerrain: string,
): number {
  const f = state.factions[factionId];
  const airTech = 1 + 0.1 * (f?.tech.air ?? 0);
  const navyTech = 1 + 0.1 * (f?.tech.navy ?? 0);
  let m = 1;
  const has = (kind: string, prov: string, fid: string) =>
    state.supports.some((s) => s.kind === kind && s.provinceId === prov && s.factionId === fid);
  const foeIds = new Set(
    state.divisions.filter((d) => d.provinceId === foeProvince).map((d) => d.factionId),
  );
  const foeHasFighter = [...foeIds].some((fid) => has("fighter", foeProvince, fid));
  if (has("fighter", ownProvince, factionId) && !foeHasFighter) m *= 1 + 0.2 * airTech;
  if (role === "atk" && has("bomber", ownProvince, factionId)) m *= 1 + 0.15 * airTech;
  if (targetTerrain === "port" || targetTerrain === "island") {
    if (has("fleet", ownProvince, factionId) || has("fleet", foeProvince, factionId)) {
      m *= 1 + 0.2 * navyTech;
    }
  }
  return m;
}

function sidePower(
  state: GameState, divs: DivisionState[], role: "atk" | "def",
  terrain: string, foeDivs: DivisionState[],
): { base: number; mult: number; terrainMult: number } {
  let base = 0;
  let multWeighted = 0;
  let terrainWeighted = 0;
  let ratioSum = 0;
  for (const div of divs) {
    const tpl: DivisionTemplate = TEMPLATES[div.templateId]!;
    const stat = role === "atk" ? tpl.attack : tpl.defense;
    const ratio = div.strength / tpl.fullStrength;
    base += stat * ratio;
    ratioSum += ratio;
    terrainWeighted += (tpl.terrainMods[terrain] ?? 1) * ratio;
    let m = tpl.terrainMods[terrain] ?? 1;
    m *= techMult(state, div, role);
    if (role === "atk" && foeDivs.length > 0) {
      // 克制：按守军编制加权的 counters 均值
      let counterSum = 0;
      let weightSum = 0;
      for (const foe of foeDivs) {
        const foeTpl = TEMPLATES[foe.templateId]!;
        counterSum += (tpl.counters[foeTpl.cls] ?? 1) * foe.strength;
        weightSum += foe.strength;
      }
      if (weightSum > 0) m *= counterSum / weightSum;
    }
    multWeighted += m * ratio;
  }
  const mult = base > 0 ? multWeighted / ratioSum : 1;
  const terrainMult = ratioSum > 0 ? terrainWeighted / ratioSum : 1;
  return { base, mult, terrainMult };
}

/** 静止层数（兵力加权平均，筹备攻势/坚守筑垒共用） */
function weightedLayers(divs: DivisionState[]): number {
  let sw = 0;
  let ss = 0;
  for (const d of divs) {
    sw += d.strength;
    ss += d.strength * Math.min(d.staticMonths, 12);
  }
  return sw > 0 ? ss / sw : 0;
}

export type AdvantageTier = "friendly" | "contested" | "enemy";

/** 三档优势工具（空优/制海同构）：比较双方在出发/目标两省的战斗机或舰队数量。 */
export function advantageTier(
  state: GameState, factionId: string, fromId: string, targetId: string, kind: "air" | "sea",
): AdvantageTier {
  const unitKind = kind === "air" ? "fighter" : "fleet";
  const inArea = (s: { provinceId: string }) => s.provinceId === fromId || s.provinceId === targetId;
  const mine = state.supports.filter(
    (s) => s.kind === unitKind && s.factionId === factionId && inArea(s),
  ).length;
  const foeFactions = new Set(
    state.divisions.filter((d) => inArea(d)).map((d) => d.factionId),
  );
  foeFactions.delete(factionId);
  const foe = state.supports.filter(
    (s) => s.kind === unitKind && foeFactions.has(s.factionId) && inArea(s),
  ).length;
  return mine > foe ? "friendly" : mine < foe ? "enemy" : "contested";
}

export interface AttackEstimate {
  atkPower: number;
  defPower: number;
  ratio: number;
  attackerCount: number;
  defenderCount: number;
}

export function estimateAttack(
  state: GameState, attackerFactionId: string, fromId: string, targetId: string,
  modeId: AttackModeId,
): AttackEstimate | null {
  const mode = ATTACK_MODES[modeId];
  if (!mode) return null;
  if (mode.effects.includes("raidOnly")) return null; // 袭扰走独立结算，无战力比预估
  const targetDef = PROVINCE_MAP[targetId];
  if (!targetDef) return null;
  const attackers = state.divisions.filter(
    (d) => d.factionId === attackerFactionId && d.provinceId === fromId && d.movedTurn < state.turn,
  );
  if (attackers.length === 0) return null;
  const defenders = defendersIn(state, attackerFactionId, targetId);
  const terrain = targetDef.terrain;
  const atk = sidePower(state, attackers, "atk", terrain, defenders);
  const def = sidePower(state, defenders, "def", terrain, attackers);
  let atkMult = atk.mult * mode.attackMult
    * supportMult(state, attackerFactionId, fromId, targetId, "atk", terrain);
  // 筹备攻势：静止层数换进攻乘区（数据表 prep）
  if (mode.prep) {
    const layers = Math.min(weightedLayers(attackers), mode.prep.maxLayers);
    atkMult *= 1 + mode.prep.perLayer * layers;
  }
  // 三档优势（空优/制海同构）+ CAS/舰炮叠加
  if (mode.tierKind && mode.tierMult) {
    const tier = advantageTier(state, attackerFactionId, fromId, targetId, mode.tierKind);
    atkMult *= mode.tierMult[tier];
    const hasKind = (kind: string) => state.supports.some(
      (s) => s.kind === kind && s.factionId === attackerFactionId
        && (s.provinceId === fromId || s.provinceId === targetId),
    );
    if (mode.casMult && hasKind("bomber")) atkMult *= mode.casMult;
    if (mode.fleetGunsMult && hasKind("fleet")) atkMult *= mode.fleetGunsMult;
  }
  let defMult = def.mult * supportMult(state, defenders[0]?.factionId ?? "", targetId, fromId, "def", terrain)
    * (terrain === "city" || terrain === "port" ? 1.15 : 1);
  // 坚守·筑垒：守方静止层数被动加防御（数据表 fortify，全模式通用）
  const fortify = ATTACK_MODES.fortified_defense.fortify;
  if (fortify && defenders.length > 0) {
    const layers = Math.min(weightedLayers(defenders), fortify.maxLayers);
    defMult *= 1 + fortify.perLayer * layers;
  }
  // 侧翼渗透：所列地形上守方地形防御减半计
  if (mode.halveDefTerrainOn?.includes(terrain) && def.terrainMult > 0) {
    defMult = (defMult / def.terrainMult) * (1 + (def.terrainMult - 1) / 2);
  }
  // 包围·断补给：目标与补给源不连通时守方战力乘子（数据表 unsuppliedDefMult）
  if (mode.unsuppliedDefMult) {
    const owner = state.provinces[targetId]?.ownerId ?? "neutral";
    if (owner !== "neutral" && !suppliedProvinces(state, owner).has(targetId)) {
      defMult *= mode.unsuppliedDefMult;
    }
  }
  const atkPower = atk.base * clamp(atkMult, MULT_MIN, MULT_MAX);
  const defPower = Math.max(def.base * clamp(defMult, MULT_MIN, MULT_MAX), 0.001);
  return {
    atkPower, defPower, ratio: atkPower / defPower,
    attackerCount: attackers.length, defenderCount: defenders.length,
  };
}

export function defendersIn(state: GameState, attackerFactionId: string, provinceId: string): DivisionState[] {
  const owner = state.provinces[provinceId]?.ownerId ?? "neutral";
  return state.divisions.filter((d) => {
    if (d.provinceId !== provinceId || d.factionId === attackerFactionId) return false;
    if (d.factionId === owner) return true; // 省份驻军（驻军方与攻方是否交战由调用方把关）
    return isAtWar(state, attackerFactionId, d.factionId); // 远征军
  });
}

export interface CombatOutcome {
  error: string | null;
  summary: string;
}

/** 游击袭扰独立结算（节点控制层，与战斗公式解耦）：得手降目标省产出（工业受损）、
 *  扰守军补给（驻军减员 5%）；驻军密度高（>=2 师）效率减半（受损 1 月、成功率降）。
 *  v1 临时反制即此密度规则；「涨根据地控制」需控制层状态，留待 v1.1 扫荡/化整为零时补。 */
function resolveRaid(
  draft: GameState, attackerFactionId: string, fromId: string, targetId: string,
  mode: AttackModeDef, attackers: DivisionState[], defenders: DivisionState[],
): CombatOutcome {
  const targetDef = PROVINCE_MAP[targetId]!;
  const dense = defenders.length >= 2;
  const rng = createRng(draft.seed).derive(`raid:${attackerFactionId}:${fromId}:${targetId}:${draft.turn}`);
  const success = rng.next() < (dense ? 0.45 : 0.8);
  for (const div of attackers) {
    div.movedTurn = draft.turn;
    div.staticMonths = 0;
  }
  let summary: string;
  if (success) {
    const months = dense ? 1 : 2;
    draft.provinces[targetId]!.damagedMonths = months;
    let defLosses = 0;
    for (const div of defenders) {
      const loss = Math.round(div.strength * 0.05);
      div.strength -= loss;
      defLosses += loss;
      div.staticMonths = 0;
    }
    summary = `${attackerFactionId} 以「${mode.name}」自 ${PROVINCE_MAP[fromId]?.name ?? fromId} 袭扰 ${targetDef.name}：`
      + `得手，${targetDef.name} 工业受损 ${months} 月、守军扰动损失 ${defLosses} 人${dense ? "（驻军密集，效率减半）" : ""}`;
  } else {
    let atkLosses = 0;
    for (const div of attackers) {
      const loss = Math.round(div.strength * 0.1);
      div.strength -= loss;
      atkLosses += loss;
    }
    draft.divisions = draft.divisions.filter((d) => {
      const threshold = TEMPLATES[d.templateId]?.guerrilla ? 150 : DESTROY_THRESHOLD;
      return d.strength >= threshold;
    });
    summary = `${attackerFactionId} 以「${mode.name}」自 ${PROVINCE_MAP[fromId]?.name ?? fromId} 袭扰 ${targetDef.name}：`
      + `未果，损失 ${atkLosses} 人`;
  }
  pushLog(draft, "battle", summary);
  return { error: null, summary };
}

export function resolveAttack(
  draft: GameState, attackerFactionId: string, fromId: string, targetId: string, modeId: AttackModeId,
): CombatOutcome {
  const mode = ATTACK_MODES[modeId];
  if (!mode) return { error: `UNKNOWN_ATTACK_MODE: ${modeId}`, summary: "" };
  const targetProv = draft.provinces[targetId];
  const targetDef = PROVINCE_MAP[targetId];
  if (!targetProv || !targetDef) return { error: `UNKNOWN_PROVINCE: ${targetId}`, summary: "" };
  const owner = targetProv.ownerId;
  const ownerAtWar = owner !== "neutral" && isAtWar(draft, attackerFactionId, owner);
  const defenders = defendersIn(draft, attackerFactionId, targetId);
  const hasEnemyPresent = defenders.some((d) => isAtWar(draft, attackerFactionId, d.factionId));
  if (!ownerAtWar && owner !== "neutral" && !hasEnemyPresent) {
    return { error: `NOT_AT_WAR: ${owner}`, summary: "" };
  }
  if (mode.requires === "seaCrossing" && !isSeaEdge(fromId, targetId)) {
    return { error: "AMPHIBIOUS_REQUIRES_SEA", summary: "" };
  }
  if (isSeaEdge(fromId, targetId) && mode.requires !== "seaCrossing"
    && !mode.effects.includes("ignoresSeaRequirement")) {
    return { error: "SEA_ATTACK_REQUIRES_AMPHIBIOUS", summary: "" };
  }
  const attackers = draft.divisions.filter(
    (d) => d.factionId === attackerFactionId && d.provinceId === fromId && d.movedTurn < draft.turn,
  );
  if (attackers.length === 0) return { error: "NO_READY_DIVISIONS", summary: "" };
  if (mode.requiresTemplates
    && !attackers.some((d) => mode.requiresTemplates!.includes(d.templateId))) {
    return { error: mode.requiresTemplatesError ?? "MODE_REQUIRES_TEMPLATE", summary: "" };
  }
  if (mode.requires === "airOrFleetSupport") {
    const supported = draft.supports.some(
      (s) => s.factionId === attackerFactionId && (s.provinceId === fromId || s.provinceId === targetId),
    );
    if (!supported) return { error: "SUPPORT_MODE_REQUIRES_AIR_OR_FLEET", summary: "" };
  }
  if (mode.requiresPortDeparture && PROVINCE_MAP[fromId]?.terrain !== "port") {
    return { error: "AMPHIBIOUS_REQUIRES_PORT_DEPARTURE", summary: "" };
  }
  // 袭扰走独立节点结算（不进战斗公式）
  if (mode.effects.includes("raidOnly")) {
    return resolveRaid(draft, attackerFactionId, fromId, targetId, mode, attackers, defenders);
  }

  const est = estimateAttack(draft, attackerFactionId, fromId, targetId, modeId)!;
  const rng = createRng(draft.seed).derive(`combat:${attackerFactionId}:${fromId}:${targetId}:${draft.turn}`);
  const atkRoll = 0.85 + rng.next() * 0.3;
  const defRoll = 0.85 + rng.next() * 0.3;
  const ratio = (est.atkPower * atkRoll) / (est.defPower * defRoll);

  const defLossRate = clamp(clamp(0.18 + 0.12 * ratio, 0.05, 0.75) * mode.defenderLossMult, 0, 0.9);
  const atkLossRate = clamp(clamp(0.3 / Math.max(ratio, 0.4), 0.05, 0.75) * mode.attackerLossMult, 0, 0.9);

  let atkLosses = 0;
  let defLosses = 0;
  for (const div of attackers) {
    const loss = Math.round(div.strength * atkLossRate);
    div.strength -= loss;
    atkLosses += loss;
    div.movedTurn = draft.turn;
    div.staticMonths = 0; // 进攻消耗筹备层
  }
  for (const div of defenders) {
    const loss = Math.round(div.strength * defLossRate);
    div.strength -= loss;
    defLosses += loss;
    div.staticMonths = 0; // 受击清筑垒层
  }
  const destroyed = new Set<string>();
  for (const div of [...attackers, ...defenders]) {
    const threshold = TEMPLATES[div.templateId]?.guerrilla ? 150 : DESTROY_THRESHOLD;
    if (div.strength < threshold) destroyed.add(div.id);
  }

  const survivingDefenders = defenders.filter((d) => !destroyed.has(d.id));
  let occupied = false;
  let encircled = false;
  if (ratio > 1 && mode.effects.includes("encircleDestroy")) {
    // 包围·断补给：目标与补给源不连通时守军无路可退（歼灭出口）
    encircled = owner !== "neutral" && !suppliedProvinces(draft, owner).has(targetId);
  }
  if (ratio > 1) {
    // 守军击退：撤往相邻己方省份；被包围断补给或无路可退则全灭
    for (const div of survivingDefenders) {
      const retreat = encircled ? undefined : neighborsOf(targetId)
        .filter((nb) => draft.provinces[nb]?.ownerId === div.factionId)
        .sort()[0];
      if (retreat) div.provinceId = retreat;
      else destroyed.add(div.id);
    }
    if (ownerAtWar || owner === "neutral") {
      targetProv.ownerId = attackerFactionId;
      occupied = true;
      for (const div of attackers) {
        if (!destroyed.has(div.id)) div.provinceId = targetId;
      }
    }
  }
  draft.divisions = draft.divisions.filter((d) => !destroyed.has(d.id));

  const attackerName = draft.factions[attackerFactionId]?.id ?? attackerFactionId;
  const summary = `${attackerName} 以「${mode.name}」自 ${PROVINCE_MAP[fromId]?.name ?? fromId} 攻 ${targetDef.name}：`
    + `战力比 ${ratio.toFixed(2)}，攻方损失 ${atkLosses} 人、守方损失 ${defLosses} 人`
    + (destroyed.size > 0 ? `，${destroyed.size} 个师被歼` : "")
    + (encircled ? "（包围断补给，守军无路可退）" : "")
    + (occupied ? `，占领 ${targetDef.name}` : ratio > 1 ? "，击退守军" : "，进攻被击退");
  pushLog(draft, "battle", summary);
  return { error: null, summary };
}
