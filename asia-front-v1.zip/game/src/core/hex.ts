// 六角格工具（尖顶 odd-r 偏移坐标）：邻居与距离。省份坐标见 data/provinces.ts。

export interface HexCoord {
  col: number;
  row: number;
}

function offsetToCube(col: number, row: number): { x: number; y: number; z: number } {
  const x = col - (row - (row & 1)) / 2;
  const z = row;
  const y = -x - z;
  return { x, y, z };
}

export function hexDistance(a: HexCoord, b: HexCoord): number {
  const ca = offsetToCube(a.col, a.row);
  const cb = offsetToCube(b.col, b.row);
  return Math.max(Math.abs(ca.x - cb.x), Math.abs(ca.y - cb.y), Math.abs(ca.z - cb.z));
}

// odd-r 六邻居偏移（按行奇偶）
const EVEN_ROW_OFFSETS: ReadonlyArray<readonly [number, number]> = [
  [1, 0], [0, -1], [-1, -1], [-1, 0], [-1, 1], [0, 1],
];
const ODD_ROW_OFFSETS: ReadonlyArray<readonly [number, number]> = [
  [1, 0], [1, -1], [0, -1], [-1, 0], [0, 1], [1, 1],
];

export function hexNeighbors(coord: HexCoord): HexCoord[] {
  const offsets = coord.row % 2 === 0 ? EVEN_ROW_OFFSETS : ODD_ROW_OFFSETS;
  return offsets.map(([dc, dr]) => ({ col: coord.col + dc, row: coord.row + dr }));
}
