// 省份图：相邻 = 六角坐标邻接（陆路）∪ seaLinks（跨海航线）。构建一次、全程只读。

import { PROVINCE_MAP, PROVINCE_IDS } from "../data/provinces";
import { hexDistance } from "./hex";

const adjacency = new Map<string, Set<string>>();
const seaEdges = new Set<string>();

function pairKey(a: string, b: string): string {
  return [a, b].sort().join("|");
}

for (const id of PROVINCE_IDS) {
  adjacency.set(id, new Set());
}
for (let i = 0; i < PROVINCE_IDS.length; i += 1) {
  for (let j = i + 1; j < PROVINCE_IDS.length; j += 1) {
    const a = PROVINCE_MAP[PROVINCE_IDS[i]!]!;
    const b = PROVINCE_MAP[PROVINCE_IDS[j]!]!;
    if (hexDistance(a, b) === 1) {
      adjacency.get(a.id)!.add(b.id);
      adjacency.get(b.id)!.add(a.id);
    }
  }
}
for (const id of PROVINCE_IDS) {
  const def = PROVINCE_MAP[id]!;
  for (const target of def.seaLinks) {
    adjacency.get(id)!.add(target);
    adjacency.get(target)?.add(id);
    seaEdges.add(pairKey(id, target));
  }
}

export function neighborsOf(provinceId: string): string[] {
  return [...(adjacency.get(provinceId) ?? [])].sort();
}

export function areAdjacent(a: string, b: string): boolean {
  return adjacency.get(a)?.has(b) ?? false;
}

export function isSeaEdge(a: string, b: string): boolean {
  return seaEdges.has(pairKey(a, b));
}

/** 经己方/同盟省份的连通域（补给线判定用）：从 from 出发只走 passable 省份可达的集合 */
export function reachableThrough(from: string, passable: (provinceId: string) => boolean): Set<string> {
  const seen = new Set<string>();
  if (!passable(from)) return seen;
  seen.add(from);
  const queue = [from];
  while (queue.length > 0) {
    const cur = queue.pop()!;
    for (const nb of neighborsOf(cur)) {
      if (!seen.has(nb) && passable(nb)) {
        seen.add(nb);
        queue.push(nb);
      }
    }
  }
  return seen;
}
