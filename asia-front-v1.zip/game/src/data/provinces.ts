// 省份节点数据（M1）：约 80 个节点（陆地 + 港口/岛屿），1936 年 1 月归属口径。
// 坐标沿用六角格 odd-r 坐标系自拟布局（col 向东、row 向南，粗略对应亚洲地理）。
// 相邻关系：陆路相邻由坐标六角邻接自动推导（core/hex），跨海航线边显式写在 seaLinks（双向，测试校验对称）。
// 资源点按史实产地挂：石油（婆罗洲/苏门答腊/缅甸/萨哈林）、橡胶（马来亚/印支/东印度）、
// 钢铁（东北/印度/日本本土）、粮食（主要农业省）。industry = 工厂数（军工+民用之和，拆分见 milShare）。
// ownerId 可为势力 id 或 "neutral"（西藏等中立地区，非势力、无状态条目）。

export type TerrainId = "plain" | "mountain" | "jungle" | "desert" | "city" | "port" | "island";

export interface ProvinceDef {
  id: string;
  name: string;
  col: number;
  row: number;
  terrain: TerrainId;
  ownerId: string; // FactionId | "neutral"
  industry: number; // 工厂总数（军工/民用按 milShare 拆分，取整）
  milShare: number; // 军工占比 0-1
  manpower: number; // 人力池基数（月增长基数）
  oil?: number; // 月产（点）
  steel?: number;
  rubber?: number;
  food?: number;
  seaLinks: string[]; // 跨海航线相邻（双向）
  isCapital?: boolean;
}

type P = Partial<ProvinceDef> & Pick<ProvinceDef, "id" | "name" | "col" | "row" | "terrain" | "ownerId">;

function p(def: P): ProvinceDef {
  return {
    industry: 0, milShare: 0.5, manpower: 20000, seaLinks: [], ...def,
  } as ProvinceDef;
}

export const PROVINCES: ProvinceDef[] = [
  // ---- 苏联远东 / 外蒙 ----
  p({ id: "irkutsk", name: "伊尔库茨克", col: 18, row: 1, terrain: "plain", ownerId: "ussr", industry: 2, manpower: 60000, food: 20 }),
  p({ id: "chita", name: "赤塔", col: 19, row: 1, terrain: "plain", ownerId: "ussr", industry: 1, manpower: 50000 }),
  p({ id: "khabarovsk", name: "伯力", col: 20, row: 1, terrain: "plain", ownerId: "ussr", industry: 1, manpower: 50000, food: 15 }),
  p({ id: "vladivostok", name: "海参崴", col: 21, row: 2, terrain: "port", ownerId: "ussr", industry: 2, milShare: 0.7, manpower: 60000, steel: 10, seaLinks: ["sakhalin", "pusan"] }),
  p({ id: "sakhalin", name: "萨哈林岛", col: 23, row: 1, terrain: "island", ownerId: "ussr", industry: 0, manpower: 20000, oil: 25, seaLinks: ["vladivostok", "sapporo"] }),
  p({ id: "ulaanbaatar", name: "乌兰巴托", col: 20, row: 3, terrain: "plain", ownerId: "mongolia", industry: 0, manpower: 25000, isCapital: true }),
  // ---- 满洲 ----
  p({ id: "harbin", name: "哈尔滨", col: 21, row: 3, terrain: "city", ownerId: "manchukuo", industry: 2, manpower: 90000, food: 40 }),
  p({ id: "changchun", name: "长春（新京）", col: 21, row: 4, terrain: "city", ownerId: "manchukuo", industry: 3, milShare: 0.6, manpower: 100000, steel: 15, food: 30, isCapital: true }),
  p({ id: "shenyang", name: "沈阳（奉天）", col: 21, row: 5, terrain: "city", ownerId: "manchukuo", industry: 4, milShare: 0.7, manpower: 110000, steel: 30, food: 25 }),
  // ---- 日本本土 / 朝鲜 / 台湾 / 关东州 ----
  p({ id: "sapporo", name: "札幌", col: 24, row: 2, terrain: "city", ownerId: "japan", industry: 1, manpower: 70000, food: 25, seaLinks: ["sakhalin", "tokyo"] }),
  p({ id: "tokyo", name: "东京", col: 25, row: 4, terrain: "port", ownerId: "japan", industry: 8, milShare: 0.6, manpower: 200000, steel: 30, isCapital: true, seaLinks: ["guam", "osaka", "sapporo"] }),
  p({ id: "osaka", name: "大阪", col: 24, row: 5, terrain: "city", ownerId: "japan", industry: 7, milShare: 0.6, manpower: 180000, steel: 25, seaLinks: ["tokyo", "nagasaki"] }),
  p({ id: "hiroshima", name: "广岛", col: 23, row: 5, terrain: "city", ownerId: "japan", industry: 3, milShare: 0.8, manpower: 90000 }),
  p({ id: "nagasaki", name: "长崎", col: 23, row: 6, terrain: "port", ownerId: "japan", industry: 3, milShare: 0.8, manpower: 80000, steel: 10, seaLinks: ["osaka", "pusan", "shanghai"] }),
  p({ id: "seoul", name: "汉城", col: 22, row: 4, terrain: "city", ownerId: "japan", industry: 1, manpower: 90000, food: 20 }),
  p({ id: "pusan", name: "釜山", col: 22, row: 5, terrain: "port", ownerId: "japan", industry: 1, manpower: 70000, seaLinks: ["nagasaki", "vladivostok", "dalian"] }),
  p({ id: "dalian", name: "大连（关东州）", col: 22, row: 6, terrain: "port", ownerId: "japan", industry: 2, milShare: 0.6, manpower: 70000, steel: 10, seaLinks: ["pusan", "tianjin", "qingdao"] }),
  p({ id: "taipei", name: "台北", col: 23, row: 12, terrain: "port", ownerId: "japan", industry: 1, manpower: 80000, food: 30, seaLinks: ["shanghai", "fuzhou", "manila"] }),
  // ---- 蒙疆 ----
  p({ id: "hohhot", name: "归绥（厚和）", col: 20, row: 5, terrain: "city", ownerId: "warlords", industry: 0, manpower: 40000, isCapital: true }),
  p({ id: "baotou", name: "包头", col: 20, row: 4, terrain: "plain", ownerId: "warlords", industry: 0, manpower: 30000 }),
  p({ id: "chahar", name: "张家口（察哈尔）", col: 21, row: 6, terrain: "mountain", ownerId: "warlords", industry: 0, manpower: 35000 }),
  // ---- 华北 ----
  p({ id: "beiping", name: "北平", col: 20, row: 6, terrain: "city", ownerId: "roc", industry: 2, manpower: 130000, food: 30 }),
  p({ id: "tianjin", name: "天津", col: 20, row: 7, terrain: "port", ownerId: "roc", industry: 2, manpower: 110000, seaLinks: ["dalian"] }),
  p({ id: "shijiazhuang", name: "石家庄", col: 19, row: 7, terrain: "plain", ownerId: "roc", industry: 1, manpower: 90000, food: 35 }),
  p({ id: "taiyuan", name: "太原", col: 18, row: 7, terrain: "mountain", ownerId: "warlords", industry: 2, milShare: 0.6, manpower: 90000, steel: 15, isCapital: true }),
  p({ id: "yanan", name: "延安", col: 18, row: 8, terrain: "mountain", ownerId: "ccp", industry: 0, manpower: 40000, isCapital: true }),
  p({ id: "jinan", name: "济南", col: 21, row: 8, terrain: "city", ownerId: "roc", industry: 1, manpower: 100000, food: 35 }),
  p({ id: "qingdao", name: "青岛", col: 22, row: 8, terrain: "port", ownerId: "roc", industry: 1, manpower: 80000, seaLinks: ["dalian", "shanghai"] }),
  p({ id: "xian", name: "西安", col: 18, row: 9, terrain: "city", ownerId: "warlords", industry: 1, manpower: 100000, food: 30 }),
  p({ id: "luoyang", name: "洛阳", col: 19, row: 9, terrain: "plain", ownerId: "roc", industry: 0, manpower: 90000, food: 40 }),
  p({ id: "zhengzhou", name: "郑州", col: 20, row: 9, terrain: "plain", ownerId: "roc", industry: 1, manpower: 100000, food: 40 }),
  p({ id: "xuzhou", name: "徐州", col: 21, row: 9, terrain: "plain", ownerId: "roc", industry: 0, manpower: 100000, food: 35 }),
  // ---- 华中 / 华东 ----
  p({ id: "wuhan", name: "武汉", col: 20, row: 10, terrain: "city", ownerId: "roc", industry: 3, milShare: 0.5, manpower: 130000, steel: 15, food: 30 }),
  p({ id: "changsha", name: "长沙", col: 20, row: 11, terrain: "city", ownerId: "roc", industry: 1, manpower: 110000, food: 45 }),
  p({ id: "hengyang", name: "衡阳", col: 20, row: 12, terrain: "plain", ownerId: "roc", industry: 0, manpower: 90000, food: 40 }),
  p({ id: "nanchang", name: "南昌", col: 21, row: 11, terrain: "city", ownerId: "roc", industry: 1, manpower: 100000, food: 40 }),
  p({ id: "nanjing", name: "南京", col: 22, row: 10, terrain: "city", ownerId: "roc", industry: 2, milShare: 0.5, manpower: 120000, isCapital: true }),
  p({ id: "shanghai", name: "上海", col: 23, row: 10, terrain: "port", ownerId: "roc", industry: 4, milShare: 0.4, manpower: 160000, steel: 10, seaLinks: ["nagasaki", "qingdao", "taipei", "hangzhou"] }),
  p({ id: "hangzhou", name: "杭州", col: 22, row: 11, terrain: "port", ownerId: "roc", industry: 1, manpower: 100000, food: 35, seaLinks: ["shanghai"] }),
  p({ id: "fuzhou", name: "福州", col: 22, row: 12, terrain: "port", ownerId: "roc", industry: 0, manpower: 90000, seaLinks: ["taipei"] }),
  // ---- 华南 / 西南 / 西北 ----
  p({ id: "guangzhou", name: "广州", col: 20, row: 13, terrain: "port", ownerId: "roc", industry: 2, milShare: 0.4, manpower: 130000, food: 30, seaLinks: ["hongkong"] }),
  p({ id: "hongkong", name: "香港", col: 21, row: 14, terrain: "port", ownerId: "uk", industry: 1, manpower: 70000, seaLinks: ["guangzhou", "hainan", "manila"] }),
  p({ id: "hainan", name: "海南岛", col: 21, row: 15, terrain: "island", ownerId: "roc", industry: 0, manpower: 50000, food: 25, seaLinks: ["hongkong", "haiphong"] }),
  p({ id: "nanning", name: "南宁", col: 18, row: 13, terrain: "city", ownerId: "warlords", industry: 0, manpower: 80000, food: 35 }),
  p({ id: "liuzhou", name: "柳州", col: 19, row: 12, terrain: "plain", ownerId: "warlords", industry: 0, manpower: 70000, food: 35 }),
  p({ id: "kunming", name: "昆明", col: 17, row: 11, terrain: "mountain", ownerId: "warlords", industry: 1, manpower: 90000, food: 30 }),
  p({ id: "chongqing", name: "重庆", col: 19, row: 10, terrain: "mountain", ownerId: "roc", industry: 1, manpower: 120000, food: 35 }),
  p({ id: "chengdu", name: "成都", col: 18, row: 10, terrain: "city", ownerId: "warlords", industry: 1, manpower: 130000, food: 50 }),
  p({ id: "guiyang", name: "贵阳", col: 18, row: 11, terrain: "mountain", ownerId: "warlords", industry: 0, manpower: 80000, food: 30 }),
  p({ id: "lanzhou", name: "兰州", col: 17, row: 9, terrain: "city", ownerId: "warlords", industry: 0, manpower: 80000, food: 25 }),
  p({ id: "yinchuan", name: "银川", col: 17, row: 7, terrain: "plain", ownerId: "warlords", industry: 0, manpower: 40000 }),
  p({ id: "xining", name: "西宁", col: 16, row: 9, terrain: "mountain", ownerId: "warlords", industry: 0, manpower: 40000 }),
  p({ id: "urumqi", name: "迪化（乌鲁木齐）", col: 15, row: 7, terrain: "city", ownerId: "warlords", industry: 0, manpower: 50000, food: 20 }),
  p({ id: "kashgar", name: "喀什", col: 14, row: 7, terrain: "desert", ownerId: "warlords", industry: 0, manpower: 40000 }),
  p({ id: "lhasa", name: "拉萨", col: 17, row: 10, terrain: "mountain", ownerId: "neutral", industry: 0, manpower: 30000 }),
  p({ id: "hami", name: "哈密", col: 16, row: 8, terrain: "desert", ownerId: "warlords", industry: 0, manpower: 20000 }),
  // ---- 印度 / 缅甸 ----
  p({ id: "delhi", name: "德里", col: 16, row: 10, terrain: "city", ownerId: "uk", industry: 2, manpower: 150000, food: 40 }),
  p({ id: "calcutta", name: "加尔各答", col: 15, row: 11, terrain: "port", ownerId: "uk", industry: 3, milShare: 0.5, manpower: 160000, steel: 25, food: 35, seaLinks: ["rangoon"] }),
  p({ id: "mandalay", name: "曼德勒", col: 16, row: 11, terrain: "city", ownerId: "uk", industry: 0, manpower: 90000, oil: 20, food: 35 }),
  p({ id: "rangoon", name: "仰光", col: 16, row: 13, terrain: "port", ownerId: "uk", industry: 1, manpower: 110000, food: 45, seaLinks: ["calcutta", "singapore"] }),
  // ---- 暹罗 / 法属印支 ----
  p({ id: "chiangmai", name: "清迈", col: 16, row: 12, terrain: "jungle", ownerId: "thailand", industry: 0, manpower: 60000, food: 30 }),
  p({ id: "bangkok", name: "曼谷", col: 18, row: 14, terrain: "port", ownerId: "thailand", industry: 1, manpower: 110000, rubber: 20, food: 45, isCapital: true, seaLinks: ["saigon", "singapore"] }),
  p({ id: "vientiane", name: "万象", col: 17, row: 12, terrain: "jungle", ownerId: "france", industry: 0, manpower: 50000, food: 30 }),
  p({ id: "hanoi", name: "河内", col: 19, row: 13, terrain: "city", ownerId: "france", industry: 1, manpower: 100000, food: 35, isCapital: true }),
  p({ id: "haiphong", name: "海防", col: 20, row: 14, terrain: "port", ownerId: "france", industry: 0, manpower: 70000, seaLinks: ["hainan", "hue"] }),
  p({ id: "hue", name: "顺化", col: 19, row: 14, terrain: "port", ownerId: "france", industry: 0, manpower: 60000, seaLinks: ["haiphong", "saigon"] }),
  p({ id: "saigon", name: "西贡", col: 19, row: 15, terrain: "port", ownerId: "france", industry: 1, manpower: 110000, rubber: 35, food: 40, seaLinks: ["hue", "bangkok", "singapore"] }),
  p({ id: "korat", name: "呵叻", col: 17, row: 13, terrain: "plain", ownerId: "thailand", industry: 0, manpower: 50000, food: 30 }),
  // ---- 马来亚 / 东印度 ----
  p({ id: "kualalumpur", name: "吉隆坡", col: 17, row: 15, terrain: "jungle", ownerId: "uk", industry: 1, manpower: 80000, rubber: 60 }),
  p({ id: "singapore", name: "新加坡", col: 18, row: 16, terrain: "port", ownerId: "uk", industry: 1, milShare: 0.6, manpower: 80000, seaLinks: ["rangoon", "bangkok", "saigon", "jakarta", "medan"] }),
  p({ id: "medan", name: "棉兰（苏门答腊）", col: 15, row: 17, terrain: "port", ownerId: "netherlands", industry: 0, manpower: 70000, oil: 40, rubber: 40, seaLinks: ["singapore", "jakarta"] }),
  p({ id: "jakarta", name: "巴达维亚（雅加达）", col: 16, row: 19, terrain: "port", ownerId: "netherlands", industry: 1, manpower: 120000, food: 35, isCapital: true, seaLinks: ["singapore", "medan", "surabaya"] }),
  p({ id: "surabaya", name: "泗水", col: 18, row: 19, terrain: "port", ownerId: "netherlands", industry: 1, manpower: 90000, seaLinks: ["jakarta", "balikpapan"] }),
  p({ id: "balikpapan", name: "巴厘巴板（婆罗洲）", col: 20, row: 18, terrain: "port", ownerId: "netherlands", industry: 0, manpower: 50000, oil: 60, rubber: 15, seaLinks: ["surabaya", "davao"] }),
  // ---- 菲律宾 / 太平洋 ----
  p({ id: "manila", name: "马尼拉", col: 24, row: 13, terrain: "port", ownerId: "usa", industry: 1, manpower: 100000, food: 30, isCapital: true, seaLinks: ["taipei", "hongkong", "davao", "guam"] }),
  p({ id: "davao", name: "达沃", col: 25, row: 15, terrain: "port", ownerId: "usa", industry: 0, manpower: 60000, seaLinks: ["manila", "balikpapan"] }),
  p({ id: "guam", name: "关岛", col: 30, row: 9, terrain: "island", ownerId: "usa", industry: 0, manpower: 15000, seaLinks: ["manila", "tokyo", "honolulu"] }),
  p({ id: "honolulu", name: "檀香山", col: 36, row: 7, terrain: "port", ownerId: "usa", industry: 2, milShare: 0.7, manpower: 60000, isCapital: true, seaLinks: ["guam"] }),
];

export const PROVINCE_MAP: Record<string, ProvinceDef> = Object.fromEntries(
  PROVINCES.map((prov) => [prov.id, prov]),
);
export const PROVINCE_IDS = PROVINCES.map((prov) => prov.id);
