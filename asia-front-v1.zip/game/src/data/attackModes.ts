// 攻击模式表 v1 定版（总管定版令，用户 02:13「攻击方式要丰富、先参考再落地」；
// 专项调研见 research_notes/asia-front-combat-modes/report.md，23 种候选筛定 8 种）。
// 全部实现为数据乘区 / 标记 / 前后钩子，结算（core/combat.ts）只读表做通用计算，
// 不许另起第二套战斗引擎、不许按 mode id 写特判；乘项积仍受 0.3-3.0 封顶。
//
// 参考/取舍：采纳钢4 决策层机制并月回合化——计划加成（筹备攻势）、筑垒（坚守）、
// 包围歼灭（断补给）、空优三档 + CAS、登陆制海门槛 + 舰炮；明确舍弃钢4 实时制细节：
// 战斗宽度、逐营属性、穿深阈值。游击袭扰走独立节点结算，与正面战斗公式解耦。
// 后续版本枚举位（本版不做）：v1.1 扫荡/化整为零/围困；v1.2 炮火支援标签/突破纵深；
// 再后 战略轰炸/破交封锁/预备队反击/夜袭/佯攻/空降/焦土。

export type AttackModeId =
  | "frontal_assault" | "prepared_offensive" | "fortified_defense" | "encirclement"
  | "infiltration" | "air_support" | "amphibious_landing" | "guerrilla_raid";

/** 特殊效果标记枚举：结算按标记做通用处理，不认具体模式 id。 */
export type AttackEffectFlag =
  | "raidOnly" // 不走战斗公式，走独立袭扰结算（降产出/补给，不占城）
  | "ignoresSeaRequirement" // 不受「跨海必须两栖」限制（小股渗透）
  | "encircleDestroy"; // 对断补给目标获胜时守军无路可退、就地歼灭

export interface TierMult {
  friendly: number; // 己方优势
  contested: number; // 争夺
  enemy: number; // 敌方优势
}

export interface AttackModeDef {
  id: AttackModeId;
  name: string;
  desc: string;
  appliesToUnits: string;
  appliesToTerrains: string;
  attackMult: number;
  attackerLossMult: number;
  defenderLossMult: number;
  requires: "none" | "seaCrossing" | "airOrFleetSupport";
  /** 参战部队须含至少一个指定模板（轻装渗透/游击专属） */
  requiresTemplates?: string[];
  requiresTemplatesError?: string;
  effects: AttackEffectFlag[];
  /** 筹备攻势：静止驻扎攒层，进攻时按层数换乘区（与坚守共用 staticMonths 字段） */
  prep?: { perLayer: number; maxLayers: number };
  /** 坚守·筑垒：守方静止攒防御层（被动生效，结算读本表此项） */
  fortify?: { perLayer: number; maxLayers: number };
  /** 渗透：所列地形上守方地形防御减半计 */
  halveDefTerrainOn?: string[];
  /** 包围：目标与补给源不连通时守方战力乘子 */
  unsuppliedDefMult?: number;
  /** 三档优势（空优/制海同一套工具函数）：air=战斗机对决，sea=舰队对决 */
  tierKind?: "air" | "sea";
  tierMult?: TierMult;
  /** 航空支援：轰炸机在场叠加的对地支援乘子（CAS） */
  casMult?: number;
  /** 两栖登陆：己方舰队在场叠加的舰炮支援乘子 */
  fleetGunsMult?: number;
  /** 两栖登陆：必须自港口省份出发 */
  requiresPortDeparture?: boolean;
}

export const ATTACK_MODES: Record<AttackModeId, AttackModeDef> = {
  frontal_assault: {
    id: "frontal_assault", name: "正面强攻",
    desc: "默认模式：全军压上，战力最高、战损也最高，适合优势兵力速决。",
    appliesToUnits: "全部师", appliesToTerrains: "全部地形",
    attackMult: 1.15, attackerLossMult: 1.2, defenderLossMult: 1.1,
    requires: "none", effects: [],
  },
  prepared_offensive: {
    id: "prepared_offensive", name: "筹备攻势",
    desc: "师静止驻扎每满 1 月攒 1 层筹备（+12%/层、上限 3 层），进攻时消耗层数换战力；移动或受击清层。",
    appliesToUnits: "全部师（需静止筹备）", appliesToTerrains: "全部地形",
    attackMult: 1.0, attackerLossMult: 1.1, defenderLossMult: 1.05,
    requires: "none", effects: [],
    prep: { perLayer: 0.12, maxLayers: 3 },
  },
  fortified_defense: {
    id: "fortified_defense", name: "坚守·筑垒",
    desc: "守方模式：静止驻扎攒防御层（+12%/层、上限 3 层，被动生效）；作为进攻选择时是低战损的坚守反击。",
    appliesToUnits: "全部师（步兵/驻防最佳）", appliesToTerrains: "全部地形",
    attackMult: 0.9, attackerLossMult: 0.7, defenderLossMult: 0.8,
    requires: "none", effects: [],
    fortify: { perLayer: 0.12, maxLayers: 3 },
  },
  encirclement: {
    id: "encirclement", name: "包围·断补给",
    desc: "对与补给源不连通的目标：守方战力减半（x0.5），且获胜时守军无路可退、就地歼灭（而非击退）。目标有补给时按普通进攻计。",
    appliesToUnits: "全部师", appliesToTerrains: "全部地形（对包围圈目标）",
    attackMult: 1.0, attackerLossMult: 1.1, defenderLossMult: 1.1,
    requires: "none", effects: ["encircleDestroy"],
    unsuppliedDefMult: 0.5,
  },
  infiltration: {
    id: "infiltration", name: "侧翼渗透",
    desc: "日军招牌打法：丛林/山地地形防御减半计，自身战损 x1.2；限轻装/山地师与日军、中共特色师。",
    appliesToUnits: "山地师/骑兵/游击队/日军步兵/海军陆战队/八路军主力师",
    appliesToTerrains: "山地、丛林最佳",
    attackMult: 1.0, attackerLossMult: 1.2, defenderLossMult: 1.0,
    requires: "none", effects: [],
    requiresTemplates: ["mountain", "cavalry", "guerrilla", "eighthRoute", "infantry_jp", "marine_jp"],
    requiresTemplatesError: "INFILTRATION_REQUIRES_LIGHT_UNIT",
    halveDefTerrainOn: ["mountain", "jungle"],
  },
  air_support: {
    id: "air_support", name: "航空支援",
    desc: "两段结算：空优三档定乘区（己方空优 x1.25 / 争夺 x1.0 / 敌方空优 x0.8），轰炸机在场再叠 CAS 近接支援 x1.15。须有支援单位在场。",
    appliesToUnits: "全部师（需空军支援单位在场）", appliesToTerrains: "全部地形",
    attackMult: 1.0, attackerLossMult: 0.85, defenderLossMult: 1.15,
    requires: "airOrFleetSupport", effects: [],
    tierKind: "air", tierMult: { friendly: 1.25, contested: 1.0, enemy: 0.8 },
    casMult: 1.15,
  },
  amphibious_landing: {
    id: "amphibious_landing", name: "两栖登陆",
    desc: "跨海专用，须自港口出发：制海权三档定乘区（己方 x1.15 / 争夺 x1.0 / 敌方 x0.75），己方舰队在场另有舰炮支援 x1.15。",
    appliesToUnits: "全部师（海军陆战队最佳）", appliesToTerrains: "跨海航线（港口出发）",
    attackMult: 0.85, attackerLossMult: 1.3, defenderLossMult: 1.0,
    requires: "seaCrossing", effects: [],
    tierKind: "sea", tierMult: { friendly: 1.15, contested: 1.0, enemy: 0.75 },
    fleetGunsMult: 1.15, requiresPortDeparture: true,
  },
  guerrilla_raid: {
    id: "guerrilla_raid", name: "游击袭扰",
    desc: "独立结算（不走战斗公式）：降目标省产出（工业受损）、扰补给，不占城；目标省驻军密度高则效率减半。游击队与八路军主力师专属。",
    appliesToUnits: "游击队/八路军主力师", appliesToTerrains: "全部地形（可小股跨海渗透）",
    attackMult: 0.7, attackerLossMult: 0.6, defenderLossMult: 1.2,
    requires: "none",
    requiresTemplates: ["guerrilla", "eighthRoute"],
    requiresTemplatesError: "GUERRILLA_MODE_REQUIRES_GUERRILLA_UNIT",
    effects: ["raidOnly", "ignoresSeaRequirement"],
  },
};
