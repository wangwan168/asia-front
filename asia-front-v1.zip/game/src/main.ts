// 《亚洲战场》第一版可玩界面（M3）：选国 -> 省份色块地图 -> 生产/科技/国策/外交/纪事全接线。
// UI 只读状态、只经 applyAction 改状态（铁律）。LLM 对话本版仅保留骨架入口（设置在纪事页）。

import { FACTIONS, FACTION_IDS, type FactionId } from "./data/factions";
import { PROVINCES, PROVINCE_MAP } from "./data/provinces";
import { TEMPLATES, SUPPORTS } from "./data/units";
import { ATTACK_MODES, type AttackModeId } from "./data/attackModes";
import { TECH_BRANCHES, TECH_BRANCH_IDS } from "./data/tech";
import { FOCUSES } from "./data/focuses";
import { DIPLOMACY_ACTIONS, relationTierOf } from "./data/diplomacy";
import { ECONOMY } from "./data/economy";
import { createInitialState } from "./state/createInitialState";
import { applyAction, type GameAction } from "./core/applyAction";
import { neighborsOf } from "./core/mapGraph";
import { reachableWithin } from "./core/movement";
import { estimateAttack } from "./core/combat";
import { isAtWar, isAllied, relationOf, factionPower, controlledProvinceCount } from "./core/relations";
import { SaveManager } from "./save/saveGame";
import { createLocalStorageAdapter } from "./save/localStorage";
import { loadLlmSettings } from "./llm/llmSettings";
import { getDiplomacyDialogEntry } from "./llm/llmClient";
import type { GameState } from "./state/types";
import "./ui/styles.css";

const app = document.getElementById("app")!;

let game: GameState | null = null;
let selectedProvince: string | null = null;
let selectedDivisionId: string | null = null;
let attackMode: AttackModeId = "frontal_assault";
let activeTab = "province";
let notice = "";
let noticeIsError = false;
let startSeed = "1936";
let startDifficulty = "normal";

const saveManager = new SaveManager(createLocalStorageAdapter());

function el<K extends keyof HTMLElementTagNameMap>(
  tag: K, className: string, text?: string,
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function dispatch(action: GameAction): boolean {
  if (!game) return false;
  const res = applyAction(game, action);
  if (res.error) {
    notice = `操作失败：${res.error}`;
    noticeIsError = true;
    if (res.error.startsWith("DIPLOMACY_REJECTED")) {
      game = res.state; // 拒绝也已产生状态变化（关系/冷却），如实呈现
    }
    render();
    return false;
  }
  game = res.state;
  notice = "";
  noticeIsError = false;
  render();
  return true;
}

function playerId(): string {
  return game?.playerFactionId ?? "roc";
}

function factionName(fid: string): string {
  return FACTIONS[fid as FactionId]?.name ?? (fid === "neutral" ? "中立地区" : fid);
}

function ownerColor(ownerId: string): string {
  return FACTIONS[ownerId as FactionId]?.colorHex ?? "#5a5a5a";
}

// ---------------- 选国界面 ----------------

const BLOC_NAMES: Record<string, string> = {
  axis: "轴心", allies: "同盟", comintern: "共产国际", neutral: "中立",
};
const DIFFICULTY_NAMES: Record<string, string> = {
  simple: "简单", normal: "普通", hard: "困难", hell: "地狱",
};

function renderStart(): void {
  app.replaceChildren();
  const wrap = el("div", "af-start");
  wrap.append(el("h1", "af-title", "亚洲战场"));
  wrap.append(el("p", "af-subtitle", "1936 年 1 月 · 月回合 · 无回合上限——只看胜负条件：控制 70% 省份，或令其余势力全灭/臣服。选择你要扮演的国家："));
  const controls = el("div", "af-start-controls");
  const seedLabel = el("label", "", "种子 ");
  const seedInput = el("input", "af-input") as HTMLInputElement;
  seedInput.value = startSeed;
  seedInput.addEventListener("change", () => { startSeed = seedInput.value || "1936"; });
  seedLabel.append(seedInput);
  const diffLabel = el("label", "", " AI 难度 ");
  const diffSelect = el("select", "af-input") as HTMLSelectElement;
  for (const [id, name] of [["easy", "简单"], ["normal", "普通"], ["hard", "困难"]] as const) {
    const opt = el("option", "", name) as HTMLOptionElement;
    opt.value = id;
    if (id === startDifficulty) opt.selected = true;
    diffSelect.append(opt);
  }
  diffSelect.addEventListener("change", () => { startDifficulty = diffSelect.value; });
  diffLabel.append(diffSelect);
  controls.append(seedLabel, diffLabel);
  wrap.append(controls);

  const grid = el("div", "af-faction-grid");
  for (const fid of FACTION_IDS) {
    const f = FACTIONS[fid];
    const card = el("button", "af-faction-card");
    card.style.borderTopColor = f.colorHex;
    const title = el("div", "af-faction-name");
    const chip = el("span", "af-chip");
    chip.style.background = f.colorHex;
    title.append(chip, document.createTextNode(f.name));
    card.append(title);
    card.append(el("div", "af-faction-line", `领袖：${f.leader.name} · 首都：${PROVINCE_MAP[f.capitalProvinceId]?.name ?? f.capitalProvinceId} · 阵营：${BLOC_NAMES[f.bloc]}`));
    card.append(el("div", "af-faction-line", f.specialty));
    const foot = el("div", "af-faction-foot");
    const diff = el("span", `af-diff af-diff-${f.difficulty.level}`, `难度：${DIFFICULTY_NAMES[f.difficulty.level]}`);
    foot.append(diff);
    foot.append(el("span", "af-faction-reason", f.difficulty.reason));
    card.append(foot);
    if (!f.startsActive && f.spawn) {
      card.append(el("div", "af-faction-line af-warn", `事件生成势力（${f.spawn.year} 年登场）；选它开局将提前激活（what-if）`));
    }
    card.addEventListener("click", () => {
      game = createInitialState({
        seed: Number.isNaN(Number(startSeed)) ? startSeed : Number(startSeed),
        playerFactionId: fid,
        difficulty: startDifficulty,
      });
      selectedProvince = f.capitalProvinceId;
      selectedDivisionId = null;
      notice = "";
      render();
    });
    grid.append(card);
  }
  wrap.append(grid);
  app.append(wrap);
}

// ---------------- 地图 ----------------

const HEX = 30;
function hexCenter(col: number, row: number): { x: number; y: number } {
  return {
    x: HEX * Math.sqrt(3) * (col + 0.5 * (row & 1)) + HEX + 10,
    y: HEX * 1.5 * row + HEX + 10,
  };
}
function hexPoints(cx: number, cy: number): string {
  const pts: string[] = [];
  for (let i = 0; i < 6; i += 1) {
    const angle = (Math.PI / 180) * (60 * i - 30);
    pts.push(`${(cx + HEX * Math.cos(angle)).toFixed(1)},${(cy + HEX * Math.sin(angle)).toFixed(1)}`);
  }
  return pts.join(" ");
}

function reachableSet(): Map<string, number> | null {
  if (!game || !selectedDivisionId) return null;
  const div = game.divisions.find((d) => d.id === selectedDivisionId);
  if (!div || div.factionId !== playerId() || div.movedTurn >= game.turn) return null;
  return reachableWithin(game, div);
}

function renderMap(): SVGElement {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  const maxCol = Math.max(...PROVINCES.map((p) => p.col));
  const maxRow = Math.max(...PROVINCES.map((p) => p.row));
  const width = HEX * Math.sqrt(3) * (maxCol + 1.5) + 20;
  const height = HEX * 1.5 * (maxRow + 1) + 20;
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("class", "af-map");
  const reach = reachableSet();
  const pid = playerId();
  for (const def of PROVINCES) {
    const st = game!.provinces[def.id]!;
    const { x, y } = hexCenter(def.col, def.row);
    const poly = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    poly.setAttribute("points", hexPoints(x, y));
    poly.setAttribute("fill", ownerColor(st.ownerId));
    let cls = "af-hex";
    if (def.id === selectedProvince) cls += " af-hex-selected";
    if (reach?.has(def.id)) cls += " af-hex-reach";
    if (selectedProvince && selectedProvince !== def.id
      && game!.divisions.some((d) => d.factionId === pid && d.provinceId === selectedProvince && d.movedTurn < game!.turn)
      && neighborsOf(selectedProvince).includes(def.id)
      && st.ownerId !== pid && st.ownerId !== "neutral"
      && isAtWar(game!, pid, st.ownerId)) {
      cls += " af-hex-attack";
    }
    poly.setAttribute("class", cls);
    poly.addEventListener("click", () => onProvinceClick(def.id));
    svg.append(poly);
    const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    label.setAttribute("x", String(x));
    label.setAttribute("y", String(y - 2));
    label.setAttribute("class", "af-hex-label");
    label.textContent = def.name.length > 5 ? def.name.slice(0, 5) : def.name;
    svg.append(label);
    const divs = game!.divisions.filter((d) => d.provinceId === def.id);
    if (divs.length > 0) {
      const badge = document.createElementNS("http://www.w3.org/2000/svg", "text");
      badge.setAttribute("x", String(x));
      badge.setAttribute("y", String(y + 11));
      badge.setAttribute("class", "af-hex-badge");
      const mine = divs.filter((d) => d.factionId === pid).length;
      badge.textContent = mine > 0 ? `⚔${divs.length}` : `·${divs.length}`;
      svg.append(badge);
    }
  }
  return svg;
}

function onProvinceClick(provinceId: string): void {
  if (!game) return;
  const pid = playerId();
  const reach = reachableSet();
  if (reach?.has(provinceId) && selectedDivisionId) {
    const divId = selectedDivisionId;
    selectedDivisionId = null;
    selectedProvince = provinceId;
    dispatch({ type: "MOVE_DIVISION", factionId: pid, divisionId: divId, toProvinceId: provinceId });
    return;
  }
  if (selectedProvince && selectedProvince !== provinceId
    && neighborsOf(selectedProvince).includes(provinceId)) {
    const target = game.provinces[provinceId]!;
    const turnNow = game.turn;
    const hasReady = game.divisions.some(
      (d) => d.factionId === pid && d.provinceId === selectedProvince && d.movedTurn < turnNow,
    );
    if (hasReady && target.ownerId !== pid && isAtWar(game, pid, target.ownerId)) {
      const from = selectedProvince;
      selectedProvince = provinceId;
      dispatch({
        type: "ATTACK", factionId: pid, fromProvinceId: from, targetProvinceId: provinceId, mode: attackMode,
      });
      return;
    }
  }
  selectedProvince = provinceId;
  selectedDivisionId = null;
  activeTab = "province";
  render();
}

// ---------------- 侧栏面板 ----------------

const TERRAIN_NAMES: Record<string, string> = {
  plain: "平原", mountain: "山地", jungle: "丛林", desert: "沙漠", city: "城市", port: "港口", island: "岛屿",
};

function renderProvincePanel(box: HTMLElement): void {
  if (!game || !selectedProvince) {
    box.append(el("p", "af-empty", "点击地图上的省份查看详情。"));
    return;
  }
  const pid = playerId();
  const def = PROVINCE_MAP[selectedProvince]!;
  const st = game.provinces[selectedProvince]!;
  box.append(el("h3", "af-panel-title", `${def.name}（${TERRAIN_NAMES[def.terrain]}）`));
  box.append(el("div", "af-line", `归属：${factionName(st.ownerId)} · 工厂：军工 ${st.factoriesMil} / 民用 ${st.factoriesCiv}`));
  const res: string[] = [];
  if (def.oil) res.push(`油 ${def.oil}/月`);
  if (def.steel) res.push(`钢 ${def.steel}/月`);
  if (def.rubber) res.push(`橡胶 ${def.rubber}/月`);
  if (def.food) res.push(`粮 ${def.food}/月`);
  box.append(el("div", "af-line", `资源：${res.length > 0 ? res.join(" · ") : "无"} · 人力池 ${def.manpower}`));

  const divs = game.divisions.filter((d) => d.provinceId === selectedProvince);
  box.append(el("h4", "af-panel-sub", `驻军（${divs.length} 个师）`));
  if (divs.length === 0) box.append(el("div", "af-line", "无驻军。"));
  for (const div of divs) {
    const tpl = TEMPLATES[div.templateId]!;
    const row = el("div", "af-div-row");
    const chip = el("span", "af-chip");
    chip.style.background = ownerColor(div.factionId);
    row.append(chip);
    row.append(el("span", "", `${factionName(div.factionId)} · ${tpl.name} · ${div.strength}/${tpl.fullStrength} 人`));
    if (div.factionId === pid) {
      const acted = div.movedTurn >= game.turn;
      const btn = el("button", "af-btn af-btn-small", acted ? "已行动" : "移动");
      btn.disabled = acted;
      btn.addEventListener("click", () => {
        selectedDivisionId = div.id;
        notice = `已选中 ${tpl.name}，点击高亮省份移动（速度 ${tpl.speed} 格/回合）。`;
        noticeIsError = false;
        render();
      });
      row.append(btn);
      if (selectedDivisionId === div.id) row.classList.add("af-div-selected");
    }
    box.append(row);
  }
  const sups = game.supports.filter((s) => s.provinceId === selectedProvince);
  if (sups.length > 0) {
    box.append(el("div", "af-line", `支援单位：${sups.map((s) => `${factionName(s.factionId)}·${SUPPORTS[s.kind].name}`).join("；")}`));
  }

  // 进攻区：本省有己方未行动部队时，列出相邻交战敌省与预估
  const turnNow = game.turn;
  const myReady = game.divisions.some(
    (d) => d.factionId === pid && d.provinceId === selectedProvince && d.movedTurn < turnNow,
  );
  if (myReady) {
    box.append(el("h4", "af-panel-sub", "进攻（选模式后点地图上的红色敌省，或点下方按钮）"));
    const modeRow = el("div", "af-mode-row");
    for (const mode of Object.values(ATTACK_MODES)) {
      const b = el("button", `af-btn af-btn-small${attackMode === mode.id ? " af-btn-active" : ""}`, mode.name);
      b.title = mode.desc;
      b.addEventListener("click", () => { attackMode = mode.id; render(); });
      modeRow.append(b);
    }
    box.append(modeRow);
    box.append(el("div", "af-line", ATTACK_MODES[attackMode].desc));
    for (const nb of neighborsOf(selectedProvince)) {
      const owner = game.provinces[nb]!.ownerId;
      if (owner === pid || owner === "neutral" || !isAtWar(game, pid, owner)) continue;
      const est = estimateAttack(game, pid, selectedProvince, nb, attackMode);
      const b = el("button", "af-btn af-btn-attack",
        `攻 ${PROVINCE_MAP[nb]!.name}（${factionName(owner)}）${est ? ` · 预估战力比 ${est.ratio.toFixed(2)}` : ""}`);
      b.addEventListener("click", () => {
        dispatch({
          type: "ATTACK", factionId: pid, fromProvinceId: selectedProvince!, targetProvinceId: nb, mode: attackMode,
        });
      });
      box.append(b);
    }
  }
}

function renderProductionPanel(box: HTMLElement): void {
  if (!game) return;
  const pid = playerId();
  const f = game.factions[pid]!;
  const target = selectedProvince && game.provinces[selectedProvince]!.ownerId === pid
    ? selectedProvince
    : FACTIONS[pid as FactionId].capitalProvinceId;
  box.append(el("h3", "af-panel-title", `生产（在 ${PROVINCE_MAP[target]?.name ?? target} 编成/建设）`));
  box.append(el("div", "af-line", `装备 ${Math.floor(f.stockpile.equipment)} · 人力 ${Math.floor(f.stockpile.manpower)} · 建设点 ${Math.floor(f.constructionPoints)}`));
  if (!target || game.provinces[target]?.ownerId !== pid) {
    box.append(el("p", "af-empty", "先在地图上选择一个己方省份作为编成地。"));
    return;
  }
  box.append(el("h4", "af-panel-sub", "编成师"));
  for (const tpl of Object.values(TEMPLATES)) {
    if (tpl.factionId && tpl.factionId !== pid) continue;
    const b = el("button", "af-btn",
      `${tpl.name}（${tpl.fullStrength} 人 · 装备 ${tpl.equipmentCost} · ${tpl.buildMonths} 月 · 攻 ${tpl.attack}/防 ${tpl.defense}）`);
    b.disabled = f.stockpile.equipment < tpl.equipmentCost || f.stockpile.manpower < tpl.fullStrength;
    b.addEventListener("click", () => {
      dispatch({ type: "BUILD_DIVISION", factionId: pid, provinceId: target, templateId: tpl.id });
    });
    box.append(b);
  }
  box.append(el("h4", "af-panel-sub", "支援单位"));
  for (const sup of Object.values(SUPPORTS)) {
    const b = el("button", "af-btn", `${sup.name}（装备 ${sup.equipmentCost} · ${sup.buildMonths} 月）`);
    b.disabled = f.stockpile.equipment < sup.equipmentCost;
    b.addEventListener("click", () => {
      dispatch({ type: "BUILD_SUPPORT", factionId: pid, provinceId: target, kind: sup.kind });
    });
    box.append(b);
  }
  box.append(el("h4", "af-panel-sub", `建厂（${ECONOMY.factoryBuildCost} 建设点 · ${ECONOMY.factoryBuildMonths} 月）`));
  for (const kind of ["mil", "civ"] as const) {
    const b = el("button", "af-btn", kind === "mil" ? "军工厂" : "民用工厂");
    b.disabled = f.constructionPoints < ECONOMY.factoryBuildCost;
    b.addEventListener("click", () => {
      dispatch({ type: "BUILD_FACTORY", factionId: pid, provinceId: target, factory: kind });
    });
    box.append(b);
  }
  box.append(el("h4", "af-panel-sub", "生产队列"));
  const queue = game.production.filter((p) => p.factionId === pid);
  if (queue.length === 0) box.append(el("div", "af-line", "队列为空。"));
  for (const item of queue) {
    const name = item.kind === "division" ? TEMPLATES[item.templateId!]!.name
      : item.kind === "support" ? SUPPORTS[item.supportKind!]!.name
        : item.kind === "factoryMil" ? "军工厂" : "民用工厂";
    box.append(el("div", "af-line", `${name} @ ${PROVINCE_MAP[item.provinceId]?.name ?? item.provinceId} · 剩 ${item.monthsLeft} 月`));
  }
}

function renderTechPanel(box: HTMLElement): void {
  if (!game) return;
  const pid = playerId();
  const f = game.factions[pid]!;
  box.append(el("h3", "af-panel-title", "科技"));
  box.append(el("div", "af-line", `研究点：${Math.floor(f.researchPoints)}（民用工厂每月 +2/座）· 当前研究：${f.researchBranch ? TECH_BRANCHES[f.researchBranch].name : "未设定"}`));
  for (const bid of TECH_BRANCH_IDS) {
    const branch = TECH_BRANCHES[bid];
    const level = f.tech[bid] ?? 0;
    const row = el("div", "af-div-row");
    row.append(el("span", "", `${branch.name} Lv.${level}/3 · ${branch.effectDesc}`));
    const next = branch.levels[level];
    const b = el("button", `af-btn af-btn-small${f.researchBranch === bid ? " af-btn-active" : ""}`,
      next ? `研究（下级 ${next.cost} 点）` : "已满级");
    b.disabled = !next;
    b.addEventListener("click", () => {
      dispatch({ type: "SET_RESEARCH", factionId: pid, branch: bid });
    });
    row.append(b);
    box.append(row);
  }
}

function renderFocusPanel(box: HTMLElement): void {
  if (!game) return;
  const pid = playerId();
  const f = game.factions[pid]!;
  box.append(el("h3", "af-panel-title", "国策"));
  if (f.focusId) {
    box.append(el("div", "af-line", `进行中：${FOCUSES.find((x) => x.id === f.focusId)?.name ?? f.focusId} · 剩 ${f.focusMonthsLeft} 月`));
  }
  for (const focus of FOCUSES.filter((x) => x.factionId === pid)) {
    const done = f.completedFocuses.includes(focus.id);
    const row = el("div", "af-div-row");
    row.append(el("span", "", `${focus.name}（${focus.months} 月）· ${focus.desc}`));
    if (!done && !f.focusId) {
      const b = el("button", "af-btn af-btn-small", "启动");
      b.addEventListener("click", () => {
        dispatch({ type: "START_FOCUS", factionId: pid, focusId: focus.id });
      });
      row.append(b);
    } else if (done) {
      row.append(el("span", "af-done", "已完成"));
    }
    box.append(row);
  }
}

function renderDiplomacyPanel(box: HTMLElement): void {
  if (!game) return;
  const pid = playerId();
  const me = game.factions[pid]!;
  box.append(el("h3", "af-panel-title", "外交"));
  if (me.vassalOf) {
    box.append(el("div", "af-line", `我国为 ${factionName(me.vassalOf)} 的附庸（每月进贡）。`));
    const b = el("button", "af-btn", "脱离附庸");
    b.addEventListener("click", () => { dispatch({ type: "BREAK_VASSAL", factionId: pid }); });
    box.append(b);
  }
  for (const fid of FACTION_IDS) {
    if (fid === pid) continue;
    const other = game.factions[fid]!;
    if (!other.active) {
      box.append(el("div", "af-line af-dim", `${factionName(fid)}：尚未登场（事件生成）`));
      continue;
    }
    if (!other.alive) {
      box.append(el("div", "af-line af-dim", `${factionName(fid)}：已出局`));
      continue;
    }
    const rel = relationOf(game, pid, fid);
    const status = isAtWar(game, pid, fid) ? "交战中"
      : other.vassalOf === pid ? "我国附庸"
        : me.vassalOf === fid ? "我国宗主"
          : isAllied(game, pid, fid) ? "盟友" : relationTierOf(rel).name;
    const head = el("div", "af-dip-head");
    const chip = el("span", "af-chip");
    chip.style.background = ownerColor(fid);
    head.append(chip);
    head.append(el("span", "", `${factionName(fid)} · 关系 ${rel}（${status}）· 战力约 ${Math.round(factionPower(game, fid))} · 控省 ${controlledProvinceCount(game, fid)}`));
    box.append(head);
    const row = el("div", "af-dip-actions");
    for (const action of DIPLOMACY_ACTIONS) {
      const b = el("button", "af-btn af-btn-small", action.name);
      b.title = `需关系 >= ${action.requiresMinRelation} · 耗装备 ${action.costEquipment}`;
      b.addEventListener("click", () => {
        dispatch({ type: "DIPLOMACY", factionId: pid, targetId: fid, actionId: action.id });
      });
      row.append(b);
    }
    box.append(row);
  }
}

function renderRecordsPanel(box: HTMLElement): void {
  if (!game) return;
  box.append(el("h3", "af-panel-title", "纪事"));
  const entry = getDiplomacyDialogEntry(loadLlmSettings(createLocalStorageAdapter()));
  box.append(el("div", "af-line", `领袖对话：${entry.label}（本版仅保留入口骨架，无 AI 也可完整游玩）`));
  box.append(el("h4", "af-panel-sub", "存档"));
  const slots = el("div", "af-dip-actions");
  for (const slot of ["manual-1", "manual-2", "manual-3"] as const) {
    const saveBtn = el("button", "af-btn af-btn-small", `存 ${slot}`);
    saveBtn.addEventListener("click", () => {
      saveManager.save(slot, game!);
      notice = `已保存到 ${slot}。`;
      noticeIsError = false;
      render();
    });
    const loadBtn = el("button", "af-btn af-btn-small", `读 ${slot}`);
    loadBtn.disabled = !saveManager.has(slot);
    loadBtn.addEventListener("click", () => {
      const res = saveManager.load(slot);
      if (res.ok) {
        game = res.state;
        selectedProvince = null;
        notice = `已读取 ${slot}。`;
        noticeIsError = false;
      } else {
        notice = `读取失败：${res.error}`;
        noticeIsError = true;
      }
      render();
    });
    slots.append(saveBtn, loadBtn);
  }
  box.append(slots);
  box.append(el("h4", "af-panel-sub", "战报与纪事（最新在前）"));
  const list = el("div", "af-log");
  for (const entryLog of [...game.log].reverse().slice(0, 120)) {
    list.append(el("div", "af-log-line", `${entryLog.year}-${String(entryLog.month).padStart(2, "0")} · ${entryLog.text}`));
  }
  box.append(list);
}

function renderTroopsPanel(box: HTMLElement): void {
  if (!game) return;
  const pid = playerId();
  box.append(el("h3", "af-panel-title", "部队"));
  const mine = game.divisions.filter((d) => d.factionId === pid);
  box.append(el("div", "af-line", `共 ${mine.length} 个师 · 总兵力 ${mine.reduce((s, d) => s + d.strength, 0)} 人`));
  for (const div of mine) {
    const tpl = TEMPLATES[div.templateId]!;
    const row = el("div", "af-div-row");
    row.append(el("span", "", `${tpl.name} @ ${PROVINCE_MAP[div.provinceId]?.name ?? div.provinceId} · ${div.strength}/${tpl.fullStrength}${div.movedTurn >= game.turn ? " · 已行动" : ""}`));
    const b = el("button", "af-btn af-btn-small", "查看");
    b.addEventListener("click", () => {
      selectedProvince = div.provinceId;
      activeTab = "province";
      render();
    });
    row.append(b);
    box.append(row);
  }
  const sups = game.supports.filter((s) => s.factionId === pid);
  if (sups.length > 0) {
    box.append(el("h4", "af-panel-sub", "支援单位"));
    for (const s of sups) {
      box.append(el("div", "af-line", `${SUPPORTS[s.kind].name} @ ${PROVINCE_MAP[s.provinceId]?.name ?? s.provinceId}`));
    }
  }
}

// ---------------- 主渲染 ----------------

const TABS: Array<{ id: string; name: string }> = [
  { id: "province", name: "省份" },
  { id: "troops", name: "部队" },
  { id: "production", name: "生产" },
  { id: "tech", name: "科技" },
  { id: "focus", name: "国策" },
  { id: "diplomacy", name: "外交" },
  { id: "records", name: "纪事" },
];

function renderGame(): void {
  if (!game) return;
  const pid = playerId();
  const f = game.factions[pid]!;
  app.replaceChildren();
  const wrap = el("div", "af-game");

  const top = el("div", "af-topbar");
  top.append(el("span", "af-game-title", "亚洲战场"));
  top.append(el("span", "af-date", `${game.year} 年 ${game.month} 月 · 第 ${game.turn} 回合`));
  top.append(el("span", "af-player", `${factionName(pid)} · 控省 ${controlledProvinceCount(game, pid)}/${Object.keys(game.provinces).length}`));
  const endBtn = el("button", "af-btn af-btn-end", "结束回合 ▶");
  endBtn.addEventListener("click", () => {
    selectedDivisionId = null;
    dispatch({ type: "END_TURN" });
  });
  const restartBtn = el("button", "af-btn", "重开一局");
  restartBtn.addEventListener("click", () => {
    game = null;
    selectedProvince = null;
    render();
  });
  top.append(endBtn, restartBtn);
  wrap.append(top);

  const sp = f.stockpile;
  const milTotal = Object.values(game.provinces).filter((p) => p.ownerId === pid)
    .reduce((s, p) => s + p.factoriesMil, 0);
  const civTotal = Object.values(game.provinces).filter((p) => p.ownerId === pid)
    .reduce((s, p) => s + p.factoriesCiv, 0);
  const resBar = el("div", "af-resbar");
  resBar.textContent = `装备 ${Math.floor(sp.equipment)} · 人力 ${Math.floor(sp.manpower)} · 油 ${Math.floor(sp.oil)} · 钢 ${Math.floor(sp.steel)} · 橡胶 ${Math.floor(sp.rubber)} · 粮 ${Math.floor(sp.food)} · 工厂 军${milTotal}/民${civTotal} · 建设点 ${Math.floor(f.constructionPoints)} · 稳定 ${Math.round(f.stability)} · 战争支持 ${Math.round(f.warSupport)}`;
  wrap.append(resBar);

  if (notice) {
    wrap.append(el("div", noticeIsError ? "af-notice af-notice-error" : "af-notice", notice));
  }

  const main = el("div", "af-main");
  const mapWrap = el("div", "af-map-wrap");
  mapWrap.append(renderMap());
  const legend = el("div", "af-legend");
  legend.textContent = "地图按归属着色；⚔ = 有驻军。先点己方省份，再点相邻红色敌省进攻；点师的「移动」后点高亮省行军。跨海进攻须选「两栖登陆」模式。";
  mapWrap.append(legend);
  main.append(mapWrap);

  const side = el("div", "af-side");
  const tabBar = el("div", "af-tabs");
  for (const tab of TABS) {
    const b = el("button", `af-tab${activeTab === tab.id ? " af-tab-active" : ""}`, tab.name);
    b.addEventListener("click", () => { activeTab = tab.id; render(); });
    tabBar.append(b);
  }
  side.append(tabBar);
  const panel = el("div", "af-panel");
  if (activeTab === "province") renderProvincePanel(panel);
  else if (activeTab === "troops") renderTroopsPanel(panel);
  else if (activeTab === "production") renderProductionPanel(panel);
  else if (activeTab === "tech") renderTechPanel(panel);
  else if (activeTab === "focus") renderFocusPanel(panel);
  else if (activeTab === "diplomacy") renderDiplomacyPanel(panel);
  else renderRecordsPanel(panel);
  side.append(panel);
  main.append(side);
  wrap.append(main);

  if (game.gameOver) {
    const overlay = el("div", "af-overlay");
    const card = el("div", "af-overlay-card");
    card.append(el("h2", "", game.gameOver.winnerId === pid ? "胜利！" : "本局结束"));
    card.append(el("p", "", game.gameOver.reason));
    const again = el("button", "af-btn af-btn-end", "再来一局");
    again.addEventListener("click", () => {
      game = null;
      selectedProvince = null;
      render();
    });
    card.append(again);
    overlay.append(card);
    wrap.append(overlay);
  }
  app.append(wrap);
}

function render(): void {
  if (!game) renderStart();
  else renderGame();
}

render();
