// 游戏状态类型（M2 完整版）。状态只经 applyAction 变更；本文件只定义形状，不含逻辑。
// 胜利口径（用户 2026-11-16 02:10 亲定）：统一胜利——控制 >=70% 省份（附庸省份计入宗主），
// 或其余势力全灭/全附庸；失去全部省份且无部队 = 出局。无回合上限（见 data/timeline.ts）。
// 玩家势力是开局参数（playerFactionId），禁止硬编码。

import type { BlocId } from "../data/factions";
import type { TechBranch } from "../data/tech";

export const STATE_VERSION = 2;

export interface ChronicleEntry {
  turn: number;
  year: number;
  month: number;
  kind: string; // "system" | "event" | "battle" | "diplomacy" | "economy"
  text: string;
}

export interface StockpileState {
  equipment: number;
  manpower: number;
  oil: number;
  steel: number;
  rubber: number;
  food: number;
}

export interface FactionState {
  id: string;
  active: boolean; // 事件生成势力未激活前为 false
  alive: boolean; // 出局（无省份且无部队）为 false
  bloc: BlocId;
  stockpile: StockpileState;
  stability: number; // 0-100
  warSupport: number; // 0-100
  tech: Record<TechBranch, number>;
  researchBranch: TechBranch | null;
  researchPoints: number;
  focusId: string | null;
  focusMonthsLeft: number;
  completedFocuses: string[];
  vassalOf: string | null; // 宗主 factionId
  constructionPoints: number;
}

export interface ProvinceState {
  id: string;
  ownerId: string; // FactionId | "neutral"
  factoriesMil: number;
  factoriesCiv: number;
  damagedMonths: number; // 工业受损剩余月数（游击袭扰 raidIndustry 打出）：>0 时本省工业产出减半
}

export interface DivisionState {
  id: string;
  factionId: string;
  templateId: string;
  provinceId: string;
  strength: number; // 当前实际人数
  movedTurn: number; // 上次移动/攻击的回合（每回合限一次行动）
  staticMonths: number; // 静止驻扎月数：筹备攻势/坚守筑垒共用层数来源（移动/进攻/受击清零）
}

export type SupportKind = "fighter" | "bomber" | "fleet";

export interface SupportState {
  id: string;
  factionId: string;
  kind: SupportKind;
  provinceId: string;
}

export interface ProductionItemState {
  id: string;
  factionId: string;
  kind: "division" | "factoryMil" | "factoryCiv" | "support";
  templateId: string | null;
  supportKind: SupportKind | null;
  provinceId: string;
  monthsLeft: number;
}

export interface GameOverState {
  winnerId: string | null;
  reason: string;
}

export interface GameState {
  version: number;
  seed: number;
  turn: number; // 从 1 开始，回合 1 = 1936 年 1 月；无上限
  year: number;
  month: number;
  playerFactionId: string | null; // 开局所选国家（默认国民政府仅为默认值，非锁定）
  difficulty: string;
  factions: Record<string, FactionState>;
  provinces: Record<string, ProvinceState>;
  divisions: DivisionState[];
  supports: SupportState[];
  production: ProductionItemState[];
  relations: Record<string, number>; // pairKey -> 0-100
  wars: string[]; // pairKey 列表
  alliances: string[]; // pairKey 列表
  tradePacts: string[]; // pairKey 列表
  nonAggression: string[]; // pairKey 列表
  diplomacyCooldowns: Record<string, number>; // `${actor}|${target}|${actionId}` -> 可用回合
  firedEvents: string[];
  gameOver: GameOverState | null;
  nextId: number;
  log: ChronicleEntry[];
}
