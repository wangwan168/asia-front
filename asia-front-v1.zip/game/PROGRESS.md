# AsiaFront (亚洲战场) — Progress

**v1 playable prototype delivered 2026-11-16 (night shift).** Stack: Vite 6 +
TypeScript (strict) + Vitest. Engine lineage: archived Daqing project
(rng / guards / save / llm / sim skeleton), all gameplay built fresh for WW2.

## What v1 contains

- **Data (src/data)**: 18 factions (historical leaders, aiPersonality +
  leader persona cards from the same source, difficulty label for the
  faction-select screen only), 78 provinces (hex odd-r layout, land
  adjacency derived from coordinates + explicit sea links, historical
  resource sites), 8 generic division templates + faction specials
  (real headcounts, infantry division = 10,000), data-driven attack modes (8 finalized: frontal/prepared/fortified/encirclement/
  infiltration/air-support CAS/amphibious/guerrilla raid, all data-driven
  with prep/fortify static-month layers and three-tier air/sea advantage), economy/tech (6 branches x 3)/focuses (3-5 per faction)/events
  (18 historical events 1936-1945)/diplomacy (7 actions).
- **Logic (src/core, src/ai)**: monthly settlement (industry, manpower,
  resources, supply-line decay, replenishment, research, focuses,
  production queues, vassal tribute, trade), movement with speed +
  sea-edge rules, combat (terrain/counters/tech/support/mode multipliers,
  product clamped 0.3-3.0, +-15% roll, losses in real headcounts,
  retreat/occupation), event interpreter, unified victory check,
  rules AI per faction personality (build/research/focus/diplomacy/
  offense/maneuver, all through applyAction only).
- **UI (src/main.ts)**: faction-select screen (18 cards with leader,
  specialty, difficulty + reason), SVG hex map colored by owner with
  click select / move highlights / attack highlights, side panels
  (province / troops / production / tech / focus / diplomacy / records
  with save slots and the LLM dialog skeleton entry), end-turn button,
  game-over overlay with restart.

## Standing rules (user, 2026-11-16)

- Starts January 1936; 1 turn = 1 month; NO turn cap anywhere — the game
  ends only on victory/defeat conditions (see src/data/timeline.ts).
- Unified victory for every faction (user 02:10, overrides per-faction
  goals): control >= 70% of provinces (vassals count toward overlord) or
  all others eliminated/vassalized; losing all provinces and divisions
  = eliminated. Faction difficulty labels are display-only.
- Player may pick any of the 18 factions (Nationalist China is only the
  default); never hardcode the player faction. Event factions
  (Wang Jingwei regime / Viet Minh / BNA / INA) activate by historical
  events, or at start if the player picks them (what-if).
- Fully playable with no LLM connected; LLM dialogue is only an extra
  negotiation channel (llm layer falls back, never blocks).
- Troop counts are real headcounts. AI difficulty only via the unified
  DIFFICULTY multiplier table (player always 1.0).
- All numbers/text in src/data; state changes only via applyAction;
  seeded RNG only via src/core/rng.ts; new logic ships with Vitest tests.

## Historical-accuracy pass (manager order, user 02:09)

- 1936 setup audited against history: Japan holds Manchuria/Korea/Taiwan;
  colonies as historical (UK Burma/Malaya/Hong Kong, France Indochina,
  Netherlands East Indies, US Philippines); CCP starts with only the
  Yan'an base area; warlords semi-autonomous (own faction, own stockpile).
- Mengjiang is now event-spawned (1939-09) like Wang Jingwei (1940-03):
  dormant in 1936, its three home provinces start under warlords and are
  transferred on activation (or at start if the player picks it).
- Events carry a `condition` field: if the player has already changed
  history (e.g. Japan-USA already at war before Dec 1941, or Haiphong no
  longer French), the event is skipped and the log records a "historical
  fork" note. US home-industry power enters via the Jan 1942
  mobilization event (overseas-support caliber, noted in faction data).
- Every faction has a `flagAsset` placeholder (flags/<id>.png); flag art
  (period-correct 1936 flags) is the art line's job, code does not draw.

## Verification (v1)

- `npm test`: 46/46 (data 13, engine 10, timeline 6, logic 12, sim 5).
- `npm run build`: passes. Preview smoke-tested (page + bundle 200).
- Sim: 300-turn full-AI runs do not crash; borders move (>= 8 provinces
  change hands by 1942); an idle ROC player is eliminated by Japan
  around 1938-1941 (regional decision before 1945); same seed = same
  result; single END_TURN with all AI settles well under 1s (~30-100ms).

## Known gaps (v1)

- Balance is rough: Japan crushes an idle player fast, but against an
  AI-driven ROC it can collapse by 1944; post-1945 stalemates are common
  (by design there is no turn cap — a balance pass is future work).
- Combat uses province-level combined arms (all ready divisions in the
  origin province attack together); no stacking limits or combat width.
- Sea movement uses abstract transport (fleet blockade only); air/naval
  units are support abstractions, not independent maneuver units.
- LLM leader dialogue is skeleton-only this version (settings + entry).
- Map art is functional color blocks; flags/art pass belongs to the art line.
