// M2 逻辑测试：月结算算例 / 生产编成 / 行军 / 战斗复现 / 外交判定 / 事件触发 / 胜负判定。

import { describe, it, expect } from "vitest";
import { createInitialState } from "../src/state/createInitialState";
import { applyAction } from "../src/core/applyAction";
import { settleAllFactions } from "../src/core/settlement";
import { checkVictory } from "../src/core/victory";
import { relationPairKey } from "../src/data/diplomacy";
import type { GameState } from "../src/state/types";

function clone(s: GameState): GameState {
  return structuredClone(s);
}

describe("月结算", () => {
  it("单省势力人力增长算例：蒙古 ulaanbaatar 人力池 25000 x 0.004 = +100/月", () => {
    const s = createInitialState({ seed: 1, playerFactionId: "roc" });
    const before = s.factions["mongolia"]!.stockpile.manpower;
    const draft = clone(s);
    settleAllFactions(draft);
    expect(draft.factions["mongolia"]!.stockpile.manpower).toBe(before + 100);
  });

  it("工业产出为正且钢消耗入账（国民政府）", () => {
    const s = createInitialState({ seed: 1, playerFactionId: "japan" });
    const draft = clone(s);
    const eqBefore = draft.factions["roc"]!.stockpile.equipment;
    settleAllFactions(draft);
    expect(draft.factions["roc"]!.stockpile.equipment).toBeGreaterThan(eqBefore);
  });

  it("无补给衰减：孤悬敌后的部队月减员 5%（游击单位豁免）", () => {
    const s = createInitialState({ seed: 1, playerFactionId: "roc" });
    const draft = clone(s);
    const div = draft.divisions.find((d) => d.factionId === "japan" && d.templateId === "infantry_jp")!;
    div.provinceId = "lhasa"; // 中立山区，与日本无补给连通
    const before = div.strength;
    settleAllFactions(draft);
    const after = draft.divisions.find((d) => d.id === div.id)!;
    expect(after.strength).toBe(Math.floor(before * 0.95));
    const guer = draft.divisions.find((d) => d.factionId === "ccp" && d.templateId === "guerrilla")!;
    const gBefore = guer.strength;
    settleAllFactions(draft);
    expect(draft.divisions.find((d) => d.id === guer.id)!.strength).toBe(gBefore);
  });
});

describe("生产编成", () => {
  it("造师：扣装备/人力入队列，3 个月后满编成军", () => {
    let s = createInitialState({ seed: 1, playerFactionId: "roc" });
    const eq = s.factions["roc"]!.stockpile.equipment;
    const mp = s.factions["roc"]!.stockpile.manpower;
    const res = applyAction(s, {
      type: "BUILD_DIVISION", factionId: "roc", provinceId: "nanjing", templateId: "infantry",
    });
    expect(res.error).toBeNull();
    s = res.state;
    expect(s.factions["roc"]!.stockpile.equipment).toBe(eq - 100);
    expect(s.factions["roc"]!.stockpile.manpower).toBe(mp - 10000);
    expect(s.production).toHaveLength(1);
    const draft = clone(s);
    settleAllFactions(draft);
    settleAllFactions(draft);
    // 编成期 3 个月：2 个月时尚未成军
    expect(draft.divisions.filter((d) => d.factionId === "roc").length)
      .toBe(s.divisions.filter((d) => d.factionId === "roc").length);
    settleAllFactions(draft);
    const rocDivs = draft.divisions.filter((d) => d.factionId === "roc");
    expect(rocDivs.length).toBe(s.divisions.filter((d) => d.factionId === "roc").length + 1);
    expect(rocDivs.some((d) => d.provinceId === "nanjing" && d.strength === 10000 && d.templateId === "infantry")).toBe(true);
  });

  it("装备不足造师被拒；他国特色师不可造", () => {
    const s = createInitialState({ seed: 1, playerFactionId: "mongolia" });
    const poor = applyAction(s, {
      type: "BUILD_DIVISION", factionId: "mongolia", provinceId: "ulaanbaatar", templateId: "armor",
    });
    expect(poor.error).toBe("INSUFFICIENT_EQUIPMENT");
    const alien = applyAction(s, {
      type: "BUILD_DIVISION", factionId: "mongolia", provinceId: "ulaanbaatar", templateId: "kwantung",
    });
    expect(alien.error).toBe("TEMPLATE_FACTION_MISMATCH");
  });
});

describe("行军", () => {
  it("速度内可达成功、超距被拒、每回合限一次", () => {
    let s = createInitialState({ seed: 1, playerFactionId: "roc" });
    const cav = s.divisions.find((d) => d.factionId === "roc" && d.templateId === "cavalry")!;
    const ok = applyAction(s, {
      type: "MOVE_DIVISION", factionId: "roc", divisionId: cav.id, toProvinceId: "taiyuan",
    });
    expect(ok.error).toBeNull();
    s = ok.state;
    expect(s.divisions.find((d) => d.id === cav.id)!.provinceId).toBe("taiyuan");
    const again = applyAction(s, {
      type: "MOVE_DIVISION", factionId: "roc", divisionId: cav.id, toProvinceId: "xian",
    });
    expect(again.error).toBe("DIVISION_ALREADY_ACTED");
    const inf = s.divisions.find((d) => d.factionId === "roc" && d.provinceId === "beiping")!;
    const far = applyAction(s, {
      type: "MOVE_DIVISION", factionId: "roc", divisionId: inf.id, toProvinceId: "tokyo",
    });
    expect(far.error).toBe("NOT_REACHABLE");
  });
});

describe("战斗", () => {
  function battleSetup() {
    const s = createInitialState({ seed: 42, playerFactionId: "thailand" });
    const draft = clone(s);
    draft.wars.push(relationPairKey("japan", "roc"));
    const jp = draft.divisions.find((d) => d.factionId === "japan" && d.templateId === "kwantung")!;
    jp.provinceId = "chahar"; // 察哈尔与北平相邻
    return draft;
  }

  it("进攻产生战损与纪事，同种子同结果（可复现）", () => {
    const runOnce = () => {
      const s = battleSetup();
      const res = applyAction(s, {
        type: "ATTACK", factionId: "japan", fromProvinceId: "chahar", targetProvinceId: "beiping", mode: "frontal_assault",
      });
      expect(res.error).toBeNull();
      return res.state;
    };
    const a = runOnce();
    const b = runOnce();
    expect(a.divisions).toEqual(b.divisions);
    expect(a.provinces["beiping"]!.ownerId).toBe(b.provinces["beiping"]!.ownerId);
    const battleLogs = a.log.filter((l) => l.kind === "battle");
    expect(battleLogs.length).toBeGreaterThanOrEqual(1);
    const totalStrength = a.divisions.reduce((sum, d) => sum + d.strength, 0);
    const initialTotal = battleSetup().divisions.reduce((sum, d) => sum + d.strength, 0);
    expect(totalStrength).toBeLessThan(initialTotal); // 有战损（实际人数减少）
  });

  it("未宣战不可进攻；跨海进攻必须用两栖模式", () => {
    const s = createInitialState({ seed: 1, playerFactionId: "thailand" });
    const noWar = applyAction(s, {
      type: "ATTACK", factionId: "japan", fromProvinceId: "dalian", targetProvinceId: "tianjin", mode: "frontal_assault",
    });
    expect(noWar.error).toContain("NOT_AT_WAR");
    const draft = clone(s);
    draft.wars.push(relationPairKey("japan", "roc"));
    const seaNoMode = applyAction(draft, {
      type: "ATTACK", factionId: "japan", fromProvinceId: "dalian", targetProvinceId: "tianjin", mode: "frontal_assault",
    });
    expect(seaNoMode.error).toBe("SEA_ATTACK_REQUIRES_AMPHIBIOUS");
    const seaOk = applyAction(draft, {
      type: "ATTACK", factionId: "japan", fromProvinceId: "dalian", targetProvinceId: "tianjin", mode: "amphibious_landing",
    });
    expect(seaOk.error).toBeNull();
  });

  it("游击模式需游击单位；炮空支援模式需支援单位在场", () => {
    const s = battleSetup();
    const bad = applyAction(s, {
      type: "ATTACK", factionId: "japan", fromProvinceId: "chahar", targetProvinceId: "beiping", mode: "guerrilla_raid",
    });
    expect(bad.error).toBe("GUERRILLA_MODE_REQUIRES_GUERRILLA_UNIT");
    const bad2 = applyAction(s, {
      type: "ATTACK", factionId: "japan", fromProvinceId: "chahar", targetProvinceId: "beiping", mode: "air_support",
    });
    expect(bad2.error).toBe("SUPPORT_MODE_REQUIRES_AIR_OR_FLEET");
  });
});

describe("外交判定（与 llm 无关）", () => {
  it("遣使升关系并扣费；宣战置零并入交战表；议和不在战时被拒", () => {
    let s = createInitialState({ seed: 1, playerFactionId: "roc" });
    const rel0 = s.relations[relationPairKey("roc", "ccp")]!;
    const envoy = applyAction(s, { type: "DIPLOMACY", factionId: "roc", targetId: "ccp", actionId: "envoy" });
    expect(envoy.error).toBeNull();
    s = envoy.state;
    expect(s.relations[relationPairKey("roc", "ccp")]).toBe(rel0 + 8);

    const war = applyAction(s, { type: "DIPLOMACY", factionId: "japan", targetId: "thailand", actionId: "declareWar" });
    expect(war.error).toBeNull();
    expect(war.state.wars).toContain(relationPairKey("japan", "thailand"));
    expect(war.state.relations[relationPairKey("japan", "thailand")]).toBe(0);

    const peace = applyAction(s, { type: "DIPLOMACY", factionId: "roc", targetId: "usa", actionId: "peace" });
    expect(peace.error).toBe("NOT_AT_WAR");
    const vassal = applyAction(s, { type: "DIPLOMACY", factionId: "roc", targetId: "japan", actionId: "vassalize" });
    expect(vassal.error).toContain("RELATION_TOO_LOW");
  });
});

describe("历史事件", () => {
  it("1936-12 西安事变触发：国共停战、关系回升", () => {
    let s = createInitialState({ seed: 9, playerFactionId: "thailand" });
    for (let i = 0; i < 11; i += 1) {
      const res = applyAction(s, { type: "END_TURN" });
      expect(res.error).toBeNull();
      s = res.state;
    }
    expect(s.year).toBe(1936);
    expect(s.month).toBe(12);
    expect(s.firedEvents).toContain("xian_incident");
    expect(s.wars).not.toContain(relationPairKey("roc", "ccp"));
    expect(s.relations[relationPairKey("roc", "ccp")]).toBeGreaterThanOrEqual(65);
  });
});

describe("胜负判定（统一口径）", () => {
  it("控制 >=70% 省份即胜；玩家出局判负方信息", () => {
    const s = createInitialState({ seed: 1, playerFactionId: "roc" });
    const draft = clone(s);
    const ids = Object.keys(draft.provinces);
    ids.forEach((pid, i) => {
      draft.provinces[pid]!.ownerId = i < Math.ceil(ids.length * 0.75) ? "japan" : "roc";
    });
    checkVictory(draft);
    expect(draft.gameOver?.winnerId).toBe("japan");
  });
});
